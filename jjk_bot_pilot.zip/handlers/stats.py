# -*- coding: utf-8 -*-
"""
Раздел "Статистика" — см. листы "Статистика (Прокачка)" и
"UI Прочие Меню" дизайн-документа.
"""

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from core.player import get_player, save_player
from core import formulas
from core import training


def _stats_text(player):
    hp = formulas.total_hp(player)
    energy = formulas.total_energy(player)
    dmg_mult = formulas.damage_multiplier(player)
    dmg_percent = round((dmg_mult - 1) * 100, 1)

    return (
        f"📊 Статистика\n\n"
        f"Уровень: {player['level']}\n"
        f"❤️ ХП: {hp}\n"
        f"🔵 Энергия: {energy}\n"
        f"💪 Бонус к урону: +{dmg_percent}%\n\n"
        f"Свободных очков: {player['stat_points_free']}\n"
        f"Вложено — ХП: {player['points_hp']} | Энергия: {player['points_energy']} | Урон: {player['points_damage']}"
    )


def _stats_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Положить очки", callback_data="stats:points")],
        [InlineKeyboardButton("⬅️ Назад", callback_data="stats:back")],
    ])


def _points_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("+10 ХП", callback_data="stats:add:hp"),
         InlineKeyboardButton("+10 Урон", callback_data="stats:add:damage"),
         InlineKeyboardButton("+10 ПЭ", callback_data="stats:add:energy")],
        [InlineKeyboardButton("🏋️ Тренировка", callback_data="stats:train")],
        [InlineKeyboardButton("⬅️ Назад", callback_data="stats:back")],
    ])


async def show_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    player = get_player(user.id, user.username)
    await update.message.reply_text(_stats_text(player), reply_markup=_stats_keyboard())


async def stats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = update.effective_user
    player = get_player(user.id, user.username)

    data = query.data

    if data == "stats:back":
        await query.edit_message_text(_stats_text(player), reply_markup=_stats_keyboard())
        return

    if data == "stats:points":
        text = (
            f"Свободных очков: {player['stat_points_free']}\n"
            f"Каждая кнопка тратит 10 очков разом на выбранную стату."
        )
        await query.edit_message_text(text, reply_markup=_points_keyboard())
        return

    if data.startswith("stats:add:"):
        stat = data.split(":")[-1]
        if player["stat_points_free"] < 10:
            await query.answer("Недостаточно свободных очков (нужно 10)!", show_alert=True)
            return
        player["stat_points_free"] -= 10
        if stat == "hp":
            player["points_hp"] += 10
        elif stat == "damage":
            player["points_damage"] += 10
        elif stat == "energy":
            player["points_energy"] += 10
        save_player(player)
        text = (
            f"Вложено! Свободных очков: {player['stat_points_free']}\n"
            f"ХП: {player['points_hp']} | Энергия: {player['points_energy']} | Урон: {player['points_damage']}"
        )
        await query.edit_message_text(text, reply_markup=_points_keyboard())
        return

    if data == "stats:train":
        buttons = InlineKeyboardMarkup([
            [InlineKeyboardButton("💪 Сила", callback_data="stats:train:damage")],
            [InlineKeyboardButton("🔵 Энергия", callback_data="stats:train:energy")],
            [InlineKeyboardButton("❤️ Здоровье", callback_data="stats:train:hp")],
            [InlineKeyboardButton("⬅️ Назад", callback_data="stats:points")],
        ])
        await query.edit_message_text("Выбери ветку тренировки:", reply_markup=buttons)
        return

    if data.startswith("stats:train:"):
        branch = data.split(":")[-1]
        n = training.start_training(user.id, branch)
        text = training.prompt_text(branch, n) + "\n\nОтправь цифру обычным сообщением в чат."
        buttons = InlineKeyboardMarkup([[InlineKeyboardButton("❌ Отмена", callback_data="stats:train:cancel")]])
        await query.edit_message_text(text, reply_markup=buttons)
        return

    if data == "stats:train:cancel":
        session = training.stop_training(user.id)
        gained = session["gained"] if session else 0
        text = f"Тренировка окончена. Набрано очков за сессию: {gained}"
        await query.edit_message_text(text, reply_markup=_points_keyboard())
        return


async def training_text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает цифры, которые игрок пишет во время тренировки.
    Возвращает True, если сообщение было "съедено" тренировкой."""
    user = update.effective_user
    session = training.get_training(user.id)
    if not session:
        return False

    text = update.message.text.strip()
    if not text.isdigit():
        return False

    guess = int(text)
    player = get_player(user.id, user.username)
    branch = session["branch"]

    if guess == session["target"]:
        session["gained"] += 1
        field = training.BRANCH_STAT_FIELD[branch]
        player[field] += 1
        save_player(player)
        new_n = training.next_number(user.id)
        reply = f"✅ Верно! +1 очко (всего за сессию: {session['gained']})\n\n{training.prompt_text(branch, new_n)}"
    else:
        reply = f"❌ Неверно. {training.prompt_text(branch, session['target'])}"

    buttons = InlineKeyboardMarkup([[InlineKeyboardButton("❌ Отмена", callback_data="stats:train:cancel")]])
    await update.message.reply_text(reply, reply_markup=buttons)
    return True

# -*- coding: utf-8 -*-
"""
/start и главное reply-меню (кнопки внизу вместо клавиатуры).
"""

from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ContextTypes

from core.player import get_player

MAIN_MENU_BUTTONS = [
    ["🧑 Персонажи", "🔨 Крафт"],
    ["🎰 Гача", "🎒 Инвентарь"],
    ["📊 Статистика", "📜 Квесты"],
    ["🗂️ Меню"],
]


def main_menu_keyboard():
    return ReplyKeyboardMarkup(MAIN_MENU_BUTTONS, resize_keyboard=True)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    player = get_player(user.id, user.username)  # авто-создаст JSON, если игрок новый

    text = (
        f"Йо, {user.first_name}!\n\n"
        f"Ты попал в мир Дзюдзюцу Кайсен. Твой стартовый персонаж — "
        f"«{player['equipped_character']}» с техникой «Кулак Дивергента».\n\n"
        f"Йен: {player['yen']}\n"
        f"Уровень: {player['level']}\n\n"
        f"Пользуйся меню внизу, чтобы качаться, крутить гачу и ходить в квесты/рейды."
    )
    await update.message.reply_text(text, reply_markup=main_menu_keyboard())


async def unknown_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Заглушка на случай, если пришёл текст, который не является числом
    (для мини-игры тренировки) и не кнопкой меню."""
    await update.message.reply_text(
        "Не понял команду. Пользуйся кнопками меню внизу.",
        reply_markup=main_menu_keyboard(),
    )

# -*- coding: utf-8 -*-
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from core.player import get_player


async def show_inventory(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    player = get_player(user.id, user.username)

    lines = ["🎒 Инвентарь\n", f"💰 Йены: {player['yen']}\n"]

    materials = player["inventory"]["materials"]
    lines.append("Материалы:")
    if materials:
        for mat, qty in materials.items():
            lines.append(f"  • {mat} ×{qty}")
    else:
        lines.append("  (пусто)")

    accessories = player["inventory"].get("accessories", [])
    lines.append("\nАксессуары:")
    if accessories:
        for a in accessories:
            lines.append(f"  • {a}")
    else:
        lines.append("  (пусто)")

    buttons = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data="inv:back")]])
    await update.message.reply_text("\n".join(lines), reply_markup=buttons)


async def inventory_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.data == "inv:back":
        await query.edit_message_text("Закрыто.")

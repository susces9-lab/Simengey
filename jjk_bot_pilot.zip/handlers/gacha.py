# -*- coding: utf-8 -*-
"""
Раздел "Гача" — см. листы "Гача" и "UI Прочие Меню" дизайн-документа.
Только базовые персонажи, без веток и прокачки.
"""

import random

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from core.player import get_player, spend_yen, add_character, add_yen
from core.game_data import game_data
from config import GACHA_COST_1X, GACHA_COST_10X


def _gacha_menu_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"Открыть 1 — {GACHA_COST_1X} Йен", callback_data="gacha:1x")],
        [InlineKeyboardButton(f"Открыть 10 — {GACHA_COST_10X} Йен", callback_data="gacha:10x")],
        [InlineKeyboardButton("📖 Индекс", callback_data="gacha:index")],
        [InlineKeyboardButton("⬅️ Назад", callback_data="gacha:back")],
    ])


async def show_gacha_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    player = get_player(user.id, user.username)
    await update.message.reply_text(
        f"🎰 Гача\nТвои Йены: {player['yen']}",
        reply_markup=_gacha_menu_keyboard(),
    )


def _pick_rarity():
    roll = random.uniform(0, 100)
    cumulative = 0.0
    for r in game_data.gacha_rarities:
        pct = float(str(r["total_chance"]).replace("%", ""))
        cumulative += pct
        if roll <= cumulative:
            return r
    return game_data.gacha_rarities[-1]


def _pick_character_from_rarity(rarity_entry):
    names = [n.strip() for n in str(rarity_entry["characters"]).split(",")]
    return random.choice(names)


def _do_single_pull(player):
    rarity_entry = _pick_rarity()
    name = _pick_character_from_rarity(rarity_entry)
    is_new = add_character(player, name)
    if not is_new:
        yen = game_data.duplicate_yen.get(rarity_entry["rarity"], 100)
        add_yen(player, yen)
        return f"🔁 {name} ({rarity_entry['rarity']}) — дубликат, +{yen} Йен"
    return f"✨ НОВЫЙ: {name} ({rarity_entry['rarity']})"


async def gacha_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = update.effective_user
    player = get_player(user.id, user.username)

    data = query.data

    if data == "gacha:back":
        await query.edit_message_text("Закрыто.")
        return

    if data == "gacha:index":
        lines = ["📖 Индекс гачи:\n"]
        for r in game_data.gacha_rarities:
            lines.append(f"{r['rarity']} — {r['total_chance']} (по {r['chance_each']} каждый)")
            lines.append(f"   {r['characters']}\n")
        buttons = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data="gacha:indexback")]])
        await query.edit_message_text("\n".join(lines), reply_markup=buttons)
        return

    if data == "gacha:indexback":
        await query.edit_message_text(f"🎰 Гача\nТвои Йены: {player['yen']}", reply_markup=_gacha_menu_keyboard())
        return

    if data == "gacha:1x":
        if not spend_yen(player, GACHA_COST_1X):
            await query.answer("Не хватает Йен!", show_alert=True)
            return
        result = _do_single_pull(player)
        from core.player import save_player
        save_player(player)
        await query.edit_message_text(
            f"{result}\n\nЙены: {player['yen']}", reply_markup=_gacha_menu_keyboard(),
        )
        return

    if data == "gacha:10x":
        if not spend_yen(player, GACHA_COST_10X):
            await query.answer("Не хватает Йен!", show_alert=True)
            return
        results = [_do_single_pull(player) for _ in range(10)]
        from core.player import save_player
        save_player(player)
        text = "🎰 Результаты 10x:\n\n" + "\n".join(results) + f"\n\nЙены: {player['yen']}"
        await query.edit_message_text(text, reply_markup=_gacha_menu_keyboard())
        return

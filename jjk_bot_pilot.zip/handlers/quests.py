# -*- coding: utf-8 -*-
"""
Раздел "Квесты" — см. лист "Квесты UI и Механика" дизайн-документа.

- Показываются только квесты, чей нижний уровень диапазона <= уровня игрока.
- Если игрок В диапазоне квеста -> награда 10 уровней.
- Если игрок ПЕРЕРОС диапазон -> только Йены (без уровней).
- Бой — последовательно N врагов одного типа.
"""

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from core.player import get_player
from core.game_data import game_data
from core import battle as battle_engine
from handlers.battle import render_battle

QUEST_LEVEL_REWARD = 10
OVERLEVELED_YEN_REWARD = 500  # за "пере-росший" квест (упрощённая фиксированная сумма для пилота)


def _in_range(player_level, quest_range):
    lo, hi = [int(x) for x in str(quest_range).split("-")]
    return lo <= player_level <= hi


async def show_quest_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    player = get_player(user.id, user.username)

    quests = game_data.available_quests(player["level"])
    if not quests:
        await update.message.reply_text("Пока нет доступных квестов для твоего уровня.")
        return

    lines = ["📜 Доступные квесты:\n"]
    buttons = []
    for q in quests:
        tag = "🟢" if _in_range(player["level"], q["range"]) else "⚪ (перерос — только Йены)"
        lines.append(f"{q['id']}. {q['range']} lvl — {q['enemy']} ×{q['count']} {tag}")
        buttons.append([InlineKeyboardButton(f"Квест {q['range']} lvl", callback_data=f"quest:{q['id']}")])

    await update.message.reply_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(buttons))


async def quest_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = update.effective_user
    player = get_player(user.id, user.username)

    data = query.data
    if data.startswith("quest:"):
        quest_id = int(data.split(":")[1])
        quest = game_data.get_quest(quest_id)
        if not quest:
            await query.edit_message_text("Квест не найден.")
            return

        in_range = _in_range(player["level"], quest["range"])
        reward_text = f"+{QUEST_LEVEL_REWARD} уровней" if in_range else f"только Йены (перерос диапазон)"
        text = (
            f"📜 Квест {quest['range']} lvl\n"
            f"Задание: убей {quest['count']}× {quest['enemy']}\n"
            f"ХП врага: {quest['enemy_hp']} | Урон врага: {quest['enemy_dmg']}\n"
            f"Награда: {reward_text}"
        )
        buttons = InlineKeyboardMarkup([
            [InlineKeyboardButton("▶️ Начать", callback_data=f"queststart:{quest_id}")],
        ])
        await query.edit_message_text(text, reply_markup=buttons)
        return

    if data.startswith("queststart:"):
        quest_id = int(data.split(":")[1])
        quest = game_data.get_quest(quest_id)
        in_range = _in_range(player["level"], quest["range"])

        enemies = [
            battle_engine.Enemy(f"{quest['enemy']} #{i+1}", quest["enemy_hp"], quest["enemy_dmg"])
            for i in range(quest["count"])
        ]

        reward = {"yen": OVERLEVELED_YEN_REWARD}
        if in_range:
            reward = {"levels": QUEST_LEVEL_REWARD}

        session = battle_engine.start_battle(
            user.id, player, enemies, on_finish_reward=reward,
            context_label=f"📜 Квест {quest['range']} lvl",
        )
        await render_battle(update, context, session, edit=True)
        return

# -*- coding: utf-8 -*-
"""
UI боя: отрисовка шкал ХП/ПЭ и обработка кнопок.
Сама логика раундов — в core/battle.py.
"""

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from core import battle as battle_engine
from core import passives as passives_module
from core.player import get_player, save_player, add_material


def _main_battle_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔵 ПТ", callback_data="battle:pt"),
         InlineKeyboardButton("⚪ ПС", callback_data="battle:ps"),
         InlineKeyboardButton("🏃 Сбежать", callback_data="battle:flee")],
    ])


def _skills_keyboard(session):
    buttons = []
    for s in session.available_skills():
        label = f"{s['name']} ({s['cost']} ПЭ)"
        if not s["usable"]:
            label = f"🔒 {label}"
        buttons.append([InlineKeyboardButton(label, callback_data=f"battle:skill:{s['num']}")])
    buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="battle:back")])
    return InlineKeyboardMarkup(buttons)


def _passives_keyboard(session):
    equipped = session.player["equipped_character"]
    ids = passives_module.available_passive_ids(session.char_state)
    buttons = []

    if "six_eyes" in ids:
        if not session.passive_state["six_eyes_active"]:
            buttons.append([InlineKeyboardButton("🔵 Six Eyes: Max Output", callback_data="battle:ps:six_eyes_1")])
        else:
            buttons.append([InlineKeyboardButton("🟣 OverPurple", callback_data="battle:ps:six_eyes_2")])

    if "sukuna_mark" in ids:
        if not session.passive_state["sukuna_mark_active"]:
            buttons.append([InlineKeyboardButton("🔴 Heian Mark", callback_data="battle:ps:sukuna_mark_1")])
        else:
            buttons.append([InlineKeyboardButton("🔴 Dimension World Slash", callback_data="battle:ps:sukuna_mark_2")])

    if "switch_mba" in ids:
        buttons.append([InlineKeyboardButton("⚪ Overhead Beast Amber", callback_data="battle:ps:switch_mba")])

    if "rkt" in ids:
        if not session.passive_state["rkt_active"]:
            buttons.append([InlineKeyboardButton("⚪ Включить RKT", callback_data="battle:ps:rkt_on")])
        else:
            buttons.append([InlineKeyboardButton("⚪ Выключить RKT", callback_data="battle:ps:rkt_off")])

    if passives_module.infinity_b1_active(session.char_state):
        buttons.append([InlineKeyboardButton("ℹ️ Бесконечность В1 (пассив, всегда вкл.)", callback_data="battle:ps:info")])

    buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="battle:back")])
    return InlineKeyboardMarkup(buttons)


async def render_battle(update: Update, context: ContextTypes.DEFAULT_TYPE, session, edit=False):
    text = session.status_text()
    keyboard = _main_battle_keyboard()

    if update.callback_query and edit:
        await update.callback_query.edit_message_text(text, reply_markup=keyboard)
    elif update.callback_query:
        await update.callback_query.message.reply_text(text, reply_markup=keyboard)
    else:
        await update.message.reply_text(text, reply_markup=keyboard)


async def battle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = update.effective_user
    session = battle_engine.get_battle(user.id)

    if not session:
        await query.edit_message_text("Бой уже завершён или не найден.")
        return

    data = query.data

    if data == "battle:flee":
        battle_engine.end_battle(user.id)
        await query.edit_message_text("🏃 Ты сбежал из боя. Награды нет.")
        return

    if data == "battle:pt":
        await query.edit_message_text(session.status_text(), reply_markup=_skills_keyboard(session))
        return

    if data == "battle:ps":
        await query.edit_message_text(session.status_text(), reply_markup=_passives_keyboard(session))
        return

    if data == "battle:ps:info":
        await query.answer("Бесконечность В1 работает автоматически, пока экипирован Годжо — −20% получаемого урона.", show_alert=True)
        return

    if data.startswith("battle:ps:"):
        passive_id = data.split("battle:ps:", 1)[1]
        ok, message = passives_module.try_activate(session, passive_id)
        if not ok:
            await query.answer(message, show_alert=True)
            return
        session.last_log = [message]

        if session.current_enemy and session.current_enemy.is_dead():
            session.enemy_index += 1
        if session.enemy_index >= len(session.enemies):
            session.finished = True
            session.victory = True
            await _finish_battle(query, user.id, session)
            return

        await query.edit_message_text(session.status_text(), reply_markup=_passives_keyboard(session))
        return

    if data == "battle:back":
        await query.edit_message_text(session.status_text(), reply_markup=_main_battle_keyboard())
        return

    if data.startswith("battle:skill:"):
        skill_num = int(data.split(":")[-1])
        ok, error = session.use_skill(skill_num)
        if not ok:
            await query.answer(error, show_alert=True)
            return

        # если враг ещё жив — он бьёт в ответ; иначе сразу переходим к следующему
        if session.current_enemy and not session.current_enemy.is_dead():
            session.enemy_turn()

        session.end_round()

        if session.finished:
            await _finish_battle(query, user.id, session)
            return

        await query.edit_message_text(session.status_text(), reply_markup=_main_battle_keyboard())
        return


async def _finish_battle(query, user_id, session):
    player = session.player
    battle_engine.end_battle(user_id)

    if not session.victory:
        # игрок проиграл — ХП персонажа "восстановится" при следующем бое (в пилоте не штрафуем дальше)
        await query.edit_message_text(
            f"{session.status_text()}\n\n💀 Поражение... Попробуй ещё раз, когда прокачаешься.",
        )
        return

    reward = session.on_finish_reward or {}
    reward_lines = ["🎉 Победа!"]

    if "quest_line_for" in reward:
        name, form = reward["quest_line_for"]
        player["characters"][name]["quest_line_done"][form] = True
        reward_lines.append(f"✅ Квест линия «{form}» для {name} пройдена!")

    if "loot_roll" in reward:
        from core import personal_boss
        character, form_index = reward["loot_roll"]
        rolled = personal_boss.roll_loot(character, form_index)
        if rolled:
            for mat, qty in rolled.items():
                add_material(player, mat, qty)
                reward_lines.append(f"🎁 Редкий дроп! +{qty}× «{mat}»")
        else:
            reward_lines.append("📦 В этот раз редкого лута не выпало — попробуй ещё раз.")

    if "branch_for" in reward:
        name, branch = reward["branch_for"]
        player["characters"][name].setdefault("branch_quest_done", {})[branch] = True
        reward_lines.append(f"✅ Квест линия ветки «{branch}» для {name} пройдена!")

    if "levels" in reward:
        player["level"] += reward["levels"]
        player["stat_points_free"] += reward["levels"] * 3
        reward_lines.append(f"⬆️ +{reward['levels']} уровней (теперь {player['level']})")

    if "yen" in reward:
        player["yen"] += reward["yen"]
        reward_lines.append(f"💰 +{reward['yen']} Йен")

    if "materials" in reward:
        for mat, qty in reward["materials"].items():
            add_material(player, mat, qty)
            reward_lines.append(f"📦 +{qty}× «{mat}»")

    if "accessory" in reward:
        acc_list = player["inventory"].setdefault("accessories", [])
        acc_list.append(reward["accessory"])
        reward_lines.append(f"💍 Получен аксессуар: {reward['accessory']}!")

    save_player(player)
    reward_lines.append("\nНажми в меню на нужный раздел, чтобы продолжить.")
    await query.edit_message_text("\n".join(reward_lines))

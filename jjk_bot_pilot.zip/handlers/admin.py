# -*- coding: utf-8 -*-
"""
Отладочные команды для быстрого тестирования механик — доступны
ТОЛЬКО пользователю с юзернеймом из DEBUG_WHITELIST_USERNAMES
(см. core/player.py, сейчас это @FallenGluton). Любой другой
пользователь получит отказ, даже если угадает синтаксис команды.

Команды:
    /give stats <0-1000> <telegram_id>   — выдать очки прокачки
    /give yen <0-10000> <telegram_id>    — выдать Йены
"""

from telegram import Update
from telegram.ext import ContextTypes

from core.player import get_player, save_player, DEBUG_WHITELIST_USERNAMES

STATS_MIN, STATS_MAX = 0, 1000
YEN_MIN, YEN_MAX = 0, 10000


def _is_authorized(user):
    return bool(user.username) and user.username.lower() in DEBUG_WHITELIST_USERNAMES


async def give_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not _is_authorized(user):
        await update.message.reply_text("⛔ Эта команда недоступна.")
        return

    args = context.args  # всё, что после /give
    if len(args) != 3:
        await update.message.reply_text(
            "Формат:\n"
            "/give stats <0-1000> <telegram_id>\n"
            "/give yen <0-10000> <telegram_id>"
        )
        return

    kind, amount_str, target_id_str = args

    if not amount_str.lstrip("-").isdigit() or not target_id_str.isdigit():
        await update.message.reply_text("Количество и telegram_id должны быть числами.")
        return

    amount = int(amount_str)
    target_id = int(target_id_str)

    target_player = get_player(target_id)  # если игрока ещё не было — создастся с нуля

    if kind == "stats":
        if not (STATS_MIN <= amount <= STATS_MAX):
            await update.message.reply_text(f"Очки должны быть в диапазоне {STATS_MIN}-{STATS_MAX}.")
            return
        target_player["stat_points_free"] += amount
        save_player(target_player)
        await update.message.reply_text(f"✅ Игроку {target_id} выдано {amount} очков прокачки.")
        return

    if kind == "yen":
        if not (YEN_MIN <= amount <= YEN_MAX):
            await update.message.reply_text(f"Йены должны быть в диапазоне {YEN_MIN}-{YEN_MAX}.")
            return
        target_player["yen"] += amount
        save_player(target_player)
        await update.message.reply_text(f"✅ Игроку {target_id} выдано {amount} Йен.")
        return

    await update.message.reply_text("Неизвестный тип — используй 'stats' или 'yen'.")

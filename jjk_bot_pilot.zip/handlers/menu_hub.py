# -*- coding: utf-8 -*-
"""
Reply-кнопка "Меню" -> инлайн-хаб: Рейды / Боссы / Нападения.
См. лист "UI Прочие Меню" дизайн-документа (блок "Меню").

Рейды играбельны: на каждый тир (T1..T5) генерируется один "боевой"
противник, масштабированный по номеру тира, а награда — Йены + 2
случайных материала из настоящего списка лута этого рейда (лист
"Рейды"). Плюс 4 рейда, к которым в дизайне привязан свой уникальный
аксессуар (Синдзюку/Проклятый Инвентарь/Метро/Миграция), выдают его
гарантированно при первой победе.
"""

import json
import random
import re

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from core.player import get_player
from core.game_data import game_data
from core import battle as battle_engine
from handlers.battle import render_battle

with open("data/raids.json", encoding="utf-8") as f:
    RAIDS = json.load(f)

RAID_ACCESSORY = {
    "Синдзюку": "Хакама Годжо",
    "Проклятый Инвентарь": "Плащ Тоджи",
    "Метро": "Маска Махито",
    "Миграция": "Кровавая Печать Кэндзяку",
}

BOSS_ACCESSORY = {
    "Мать Проклятий": "Осколок Материнской Скорби",
    "Дьявол Разрушения": "Клык Разрушителя",
    "Тенген": "Печать Барьерного Мастера",
    "Слияние Смертельных Картин": "Тройная Печать Смерти",
    "Двойное Слияние: Кэндзяку/Сукуна": "Кольцо Тысячелетнего Слияния",
    "Проклятый Король Пустоты": "Корона Пустотного Короля",
}


def _tier_number(tier_text):
    m = re.match(r"T(\d)", tier_text)
    return int(m.group(1)) if m else 1


def _raid_enemy_stats(tier_num):
    hp = 300 * (tier_num ** 2) + 500
    dmg = int(hp * 0.10)
    return hp, dmg


def _raid_loot_materials(raid):
    return re.findall(r"«([^»]+)»", raid["loot"])


def _hub_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🗺️ Рейды", callback_data="hub:raids")],
        [InlineKeyboardButton("👹 Боссы", callback_data="hub:bosses")],
        [InlineKeyboardButton("👤 Личные Боссы", callback_data="hub:personal")],
        [InlineKeyboardButton("⚔️ Нападения", callback_data="hub:attacks")],
        [InlineKeyboardButton("⬅️ Назад", callback_data="hub:back")],
    ])


async def show_menu_hub(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🗂️ Меню:", reply_markup=_hub_keyboard())


async def raids_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Прямой вход в список рейдов, команда /raids — запасной путь в обход кнопки «Меню»."""
    buttons = [[InlineKeyboardButton(f"[{r['tier'].split(' ')[0]}] {r['name']}", callback_data=f"hub:raid:{r['name']}")] for r in RAIDS]
    await update.message.reply_text("🗺️ Выбери рейд:", reply_markup=InlineKeyboardMarkup(buttons))


async def bosses_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Прямой вход в список боссов, команда /bosses — запасной путь в обход кнопки «Меню»."""
    buttons = [[InlineKeyboardButton(b["name"], callback_data=f"hub:boss:{i}")] for i, b in enumerate(game_data.bosses)]
    await update.message.reply_text("👹 Выбери босса:", reply_markup=InlineKeyboardMarkup(buttons))


async def menu_hub_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = update.effective_user
    player = get_player(user.id, user.username)
    data = query.data

    if data == "hub:back":
        await query.edit_message_text("Закрыто.")
        return

    if data == "hub:raids":
        buttons = [[InlineKeyboardButton(f"[{r['tier'].split(' ')[0]}] {r['name']}", callback_data=f"hub:raid:{r['name']}")] for r in RAIDS]
        buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="hub:backto")])
        await query.edit_message_text("🗺️ Выбери рейд:", reply_markup=InlineKeyboardMarkup(buttons))
        return

    if data.startswith("hub:raid:"):
        name = data.split("hub:raid:", 1)[1]
        raid = next((r for r in RAIDS if r["name"] == name), None)
        if not raid:
            await query.edit_message_text("Рейд не найден.")
            return
        tier_num = _tier_number(raid["tier"])
        hp, dmg = _raid_enemy_stats(tier_num)
        loot_preview = ", ".join(_raid_loot_materials(raid)[:6])
        text = (
            f"🗺️ {raid['name']} ({raid['tier']})\n"
            f"ХП противника: {hp} | Урон: {dmg}\n\n"
            f"Возможный лут: {loot_preview}...\n"
            f"{raid.get('note', '')}"
        )
        buttons = InlineKeyboardMarkup([
            [InlineKeyboardButton("▶️ Начать бой", callback_data=f"hub:raidfight:{name}")],
            [InlineKeyboardButton("⬅️ Назад", callback_data="hub:raids")],
        ])
        await query.edit_message_text(text, reply_markup=buttons)
        return

    if data.startswith("hub:raidfight:"):
        name = data.split("hub:raidfight:", 1)[1]
        raid = next((r for r in RAIDS if r["name"] == name), None)
        tier_num = _tier_number(raid["tier"])
        hp, dmg = _raid_enemy_stats(tier_num)

        loot = _raid_loot_materials(raid)
        materials_reward = {}
        for mat in random.sample(loot, min(2, len(loot))):
            materials_reward[mat] = materials_reward.get(mat, 0) + 1

        reward = {"yen": 200 * tier_num, "materials": materials_reward}
        if name in RAID_ACCESSORY:
            reward["accessory"] = RAID_ACCESSORY[name]

        enemy = battle_engine.Enemy(f"Противник рейда: {raid['name']}", hp, dmg)
        session = battle_engine.start_battle(
            user.id, player, [enemy], on_finish_reward=reward,
            context_label=f"🗺️ Рейд: {raid['name']}",
        )
        await render_battle(update, context, session, edit=True)
        return

    if data == "hub:bosses":
        buttons = [[InlineKeyboardButton(b["name"], callback_data=f"hub:boss:{i}")] for i, b in enumerate(game_data.bosses)]
        buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="hub:backto")])
        await query.edit_message_text("👹 Выбери босса:", reply_markup=InlineKeyboardMarkup(buttons))
        return

    if data.startswith("hub:boss:"):
        idx = int(data.split("hub:boss:", 1)[1])
        boss = game_data.bosses[idx]
        name = boss["name"]
        acc = BOSS_ACCESSORY.get(name, "—")
        text = (
            f"👹 {boss['name']}\nУровень: {boss['level_range']}\nХП: {boss['hp']} | Урон: {boss['damage']}\n\n"
            f"{boss['lore']}\n\nНаграда: {boss['reward']}\nАксессуар за победу: {acc}"
        )
        buttons = InlineKeyboardMarkup([
            [InlineKeyboardButton("▶️ Начать бой (соло)", callback_data=f"hub:bossfight:{idx}")],
            [InlineKeyboardButton("👥 Совместный рейд", callback_data=f"hub:coopboss:{idx}")],
            [InlineKeyboardButton("⬅️ Назад", callback_data="hub:bosses")],
        ])
        await query.edit_message_text(text, reply_markup=buttons)
        return

    if data.startswith("hub:coopboss:"):
        idx = int(data.split("hub:coopboss:", 1)[1])
        boss = game_data.bosses[idx]
        enemy = battle_engine.Enemy(boss["name"], boss["hp"], boss["damage"])
        from handlers.coop import start_coop_raid
        await start_coop_raid(update, context, boss, enemy)
        return

    if data.startswith("hub:bossfight:"):
        idx = int(data.split("hub:bossfight:", 1)[1])
        boss = game_data.bosses[idx]
        name = boss["name"]
        reward = {"yen": 5000}
        if name in BOSS_ACCESSORY:
            reward["accessory"] = BOSS_ACCESSORY[name]
        enemy = battle_engine.Enemy(boss["name"], boss["hp"], boss["damage"])
        session = battle_engine.start_battle(
            user.id, player, [enemy], on_finish_reward=reward,
            context_label=f"👹 Босс: {boss['name']}",
        )
        await render_battle(update, context, session, edit=True)
        return

    if data == "hub:personal":
        owned = list(player["characters"].keys())
        buttons = [[InlineKeyboardButton(n, callback_data=f"hub:personalchar:{n}")] for n in owned]
        buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="hub:backto")])
        await query.edit_message_text(
            "👤 Личные Боссы — фарм без каких-либо условий входа.\n"
            "Уровень босса = текущий уровень техники персонажа. Пока не прокачаешь "
            "персонажа на след. уровень (крафтом), босс останется прежним — можно "
            "фармить его сколько угодно раз на редкий шанс материалов под левел-ап.\n\n"
            "Выбери персонажа:",
            reply_markup=InlineKeyboardMarkup(buttons),
        )
        return

    if data.startswith("hub:personalchar:"):
        name = data.split("hub:personalchar:", 1)[1]
        from core import personal_boss
        char_state = player["characters"][name]
        form_index = char_state["form_index"]
        form, attack = personal_boss.get_personal_boss(name, form_index)
        if not attack:
            await query.edit_message_text(
                "Для этого персонажа личный босс ещё не настроен.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data="hub:personal")]]),
            )
            return
        text = (
            f"👤 Личный босс: {name} (текущий уровень техники)\n"
            f"Форма: {form}\n"
            f"ХП: {attack['enemy_hp']} | Урон: {attack['enemy_dmg']}\n\n"
            f"Победа: автоматически засчитывает квест-линию этого уровня + шанс редкого "
            f"дропа материалов под следующий уровень."
        )
        buttons = InlineKeyboardMarkup([
            [InlineKeyboardButton("▶️ Начать бой", callback_data=f"hub:personalfight:{name}")],
            [InlineKeyboardButton("⬅️ Назад", callback_data="hub:personal")],
        ])
        await query.edit_message_text(text, reply_markup=buttons)
        return

    if data.startswith("hub:personalfight:"):
        name = data.split("hub:personalfight:", 1)[1]
        from core import personal_boss
        char_state = player["characters"][name]
        form_index = char_state["form_index"]
        form, attack = personal_boss.get_personal_boss(name, form_index)
        enemy = battle_engine.Enemy(f"Личный босс: {name} ({form})", attack["enemy_hp"], attack["enemy_dmg"])
        session = battle_engine.start_battle(
            user.id, player, [enemy],
            on_finish_reward={"quest_line_for": (name, form), "loot_roll": (name, form_index)},
            context_label=f"👤 Личный босс: {name}",
        )
        await render_battle(update, context, session, edit=True)
        return

    if data == "hub:attacks":
        owned = list(player["characters"].keys())
        buttons = [[InlineKeyboardButton(n, callback_data=f"char:{n}")] for n in owned]
        buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="hub:backto")])
        await query.edit_message_text(
            "⚔️ Нападения — выбери персонажа, откроется его карточка, "
            "там кнопка «Квест линия» запускает личный бой:",
            reply_markup=InlineKeyboardMarkup(buttons),
        )
        return

    if data == "hub:backto":
        await query.edit_message_text("🗂️ Меню:", reply_markup=_hub_keyboard())
        return

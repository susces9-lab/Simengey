# -*- coding: utf-8 -*-
"""
Раздел "Персонажи": список владения, карточка персонажа,
квест-линия / повышение уровня / расширение / аксессуар / пассивки.

См. лист "UI Раздел Персонажей" дизайн-документа.

ВАЖНО ПРО CALLBACK_DATA: Telegram ограничивает callback_data 64 байтами.
Названия веток ("Ветка: Модульная (Сукуна19+Чосо макс) (Celestial)")
сами по себе под сотню байт, поэтому НИГДЕ не кладём текст ветки/
аксессуара в callback_data — только числовые ИНДЕКСЫ в соответствующих
списках (список веток персонажа, список аксессуаров в инвентаре и т.д.),
и уже внутри обработчика превращаем индекс обратно в текст.
"""

import re

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from core.player import get_player, save_player, has_materials, spend_materials
from core.game_data import game_data
from core import battle as battle_engine
from core import economy
from core import passives as passives_module


def _branch_forms(name):
    """Все формы персонажа, которые являются ветками/расширениями (не основная линия)."""
    forms = game_data.get_character_forms(name)
    return [f for f in forms if f.startswith("Ветка:") or f.startswith("Авекинг:")]


def _base_forms(name):
    forms = game_data.get_character_forms(name)
    return [f for f in forms if not (f.startswith("Ветка:") or f.startswith("Авекинг:"))]


def _branch_rank(branch_label):
    m = re.search(r"\(([^)]+)\)\s*$", branch_label)
    return m.group(1) if m else "Special"


def _branch_core_name(label):
    """Убирает префикс 'Ветка:'/'Авекинг:' и хвостовую скобку с рангом —
    нужно, чтобы сопоставлять формы из skills.json и attacks.json,
    у которых названия записаны чуть по-разному."""
    s = re.sub(r"^(Ветка|Авекинг):\s*", "", label)
    s = re.sub(r"\s*\([^)]*\)\s*$", "", s)
    return s.strip()


async def show_character_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    player = get_player(user.id, user.username)

    buttons = []
    for name in player["characters"].keys():
        buttons.append([InlineKeyboardButton(name, callback_data=f"char:{name}")])

    await update.message.reply_text(
        "🧑 Твои персонажи:",
        reply_markup=InlineKeyboardMarkup(buttons),
    )


def _character_card_text(player, name):
    char_state = player["characters"][name]
    char_info = game_data.get_character(name) or {}
    base_forms = _base_forms(name)
    form_index = min(char_state["form_index"], max(len(base_forms) - 1, 0))
    active_branch = char_state.get("active_branch")
    form = active_branch if active_branch else (base_forms[form_index] if base_forms else "—")

    quest_done = char_state["quest_line_done"].get(base_forms[form_index] if base_forms else "", False)
    quest_icon = "✅" if quest_done else "❌"

    skills = game_data.get_skills_for_form(name, form)
    skills_text = "\n".join(f"  • {s['name']} (КД {s['cooldown']}, {s['cost']} ПЭ)" for s in skills) or "  (нет данных)"

    acc = char_state.get("accessory")
    acc_text = acc if acc else "не экипирован"

    if active_branch:
        current_text = f"Активная ветка: {active_branch}"
    else:
        current_text = f"Текущая форма: {form}"

    next_form = base_forms[form_index + 1] if form_index + 1 < len(base_forms) else None
    next_text = f"Следующий уровень: «{next_form}» (нужна пройденная квест-линия + материалы)" if next_form else "Это максимальная база персонажа."

    return (
        f"🧑 {name}\n"
        f"Редкость: {char_info.get('rarity', '?')} | Ранг: {char_info.get('base_rank', '?')}\n"
        f"{current_text}\n"
        f"Квест линия (текущий базовый уровень): {quest_icon}\n"
        f"Аксессуар: {acc_text}\n\n"
        f"Скилы:\n{skills_text}\n\n"
        f"{next_text}"
    )


def _character_card_keyboard(name, player):
    buttons = []
    if player.get("equipped_character") != name:
        buttons.append([InlineKeyboardButton("▶️ Сделать активным", callback_data=f"charequip:{name}")])
    buttons += [
        [InlineKeyboardButton("📜 Квест линия", callback_data=f"charquest:{name}")],
        [InlineKeyboardButton("⬆️ Повысить уровень", callback_data=f"charlvlup:{name}")],
        [InlineKeyboardButton("🌿 Расширение", callback_data=f"charbranch:{name}")],
        [InlineKeyboardButton("💍 Аксессуар", callback_data=f"characc:{name}")],
        [InlineKeyboardButton("🌀 Пассивки", callback_data=f"charpassives:{name}")],
        [InlineKeyboardButton("⬅️ Назад", callback_data="charback")],
    ]
    return InlineKeyboardMarkup(buttons)


async def character_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = update.effective_user
    player = get_player(user.id, user.username)

    data = query.data

    if data == "charback":
        buttons = [[InlineKeyboardButton(n, callback_data=f"char:{n}")] for n in player["characters"].keys()]
        await query.edit_message_text("🧑 Твои персонажи:", reply_markup=InlineKeyboardMarkup(buttons))
        return

    if data.startswith("char:"):
        name = data.split("char:", 1)[1]
        await query.edit_message_text(_character_card_text(player, name), reply_markup=_character_card_keyboard(name, player))
        return

    if data.startswith("charquest:"):
        name = data.split("charquest:", 1)[1]
        await _start_quest_line_fight(update, context, player, name)
        return

    if data.startswith("charlvlup:"):
        name = data.split("charlvlup:", 1)[1]
        await _try_level_up(query, player, name)
        return

    if data.startswith("charbranch:"):
        name = data.split("charbranch:", 1)[1]
        await _show_branch_menu(query, player, name)
        return

    if data.startswith("branchinfo:"):
        _, name, idx = data.split(":", 2)
        branch = _branch_forms(name)[int(idx)]
        await _show_branch_card(query, player, name, branch)
        return

    if data.startswith("branchquest:"):
        _, name, idx = data.split(":", 2)
        branch = _branch_forms(name)[int(idx)]
        await _start_branch_quest_fight(update, context, player, name, branch)
        return

    if data.startswith("branchunlock:"):
        _, name, idx = data.split(":", 2)
        branch = _branch_forms(name)[int(idx)]
        await _try_unlock_branch(query, player, name, branch)
        return

    if data.startswith("branchactivate:"):
        _, name, idx = data.split(":", 2)
        branch = _branch_forms(name)[int(idx)]
        player["characters"][name]["active_branch"] = branch
        save_player(player)
        await query.edit_message_text(_character_card_text(player, name), reply_markup=_character_card_keyboard(name, player))
        return

    if data.startswith("branchdeactivate:"):
        name = data.split("branchdeactivate:", 1)[1]
        player["characters"][name]["active_branch"] = None
        save_player(player)
        await query.edit_message_text(_character_card_text(player, name), reply_markup=_character_card_keyboard(name, player))
        return

    if data.startswith("characc:"):
        name = data.split("characc:", 1)[1]
        await _show_accessory_menu(query, player, name)
        return

    if data.startswith("charpassives:"):
        name = data.split("charpassives:", 1)[1]
        await _show_passives_menu(query, player, name)
        return

    if data.startswith("togglepassive:"):
        _, name, pid = data.split(":", 2)
        char_state = player["characters"][name]
        equipped = char_state.setdefault("equipped_passives", [])
        if pid in equipped:
            equipped.remove(pid)
        else:
            if len(equipped) >= economy.MAX_EQUIPPED_PASSIVES_PER_CHARACTER:
                await query.answer(f"Максимум {economy.MAX_EQUIPPED_PASSIVES_PER_CHARACTER} пассивки на персонажа — сначала сними одну.", show_alert=True)
                return
            equipped.append(pid)
        save_player(player)
        await _show_passives_menu(query, player, name)
        return

    if data.startswith("equipacc:"):
        _, char_idx, acc_idx = data.split(":", 2)
        name = list(player["characters"].keys())[int(char_idx)]
        owned = player["inventory"].get("accessories", [])
        acc_name = owned[int(acc_idx)]
        player["characters"][name]["accessory"] = acc_name
        save_player(player)
        await query.edit_message_text(_character_card_text(player, name), reply_markup=_character_card_keyboard(name, player))
        return

    if data.startswith("charequip:"):
        name = data.split("charequip:", 1)[1]
        player["equipped_character"] = name
        save_player(player)
        await query.edit_message_text(_character_card_text(player, name), reply_markup=_character_card_keyboard(name, player))
        return


async def _show_accessory_menu(query, player, name):
    owned = player["inventory"].get("accessories", [])
    char_idx = list(player["characters"].keys()).index(name)
    if not owned:
        text = "У тебя пока нет ни одного аксессуара (они падают с боссов и некоторых рейдов)."
        buttons = [[InlineKeyboardButton("⬅️ Назад", callback_data=f"char:{name}")]]
    else:
        text = "Выбери аксессуар для экипировки:"
        buttons = [[InlineKeyboardButton(a, callback_data=f"equipacc:{char_idx}:{i}")] for i, a in enumerate(owned)]
        buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data=f"char:{name}")])
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(buttons))


async def _show_passives_menu(query, player, name):
    owned = player["inventory"].get("passives", [])
    char_state = player["characters"][name]
    equipped = char_state.get("equipped_passives", [])

    if not owned:
        text = "У тебя нет ни одной скрафченной пассивки — сделай это через 🔨 Крафт → 🌀 Пассивки."
        buttons = [[InlineKeyboardButton("⬅️ Назад", callback_data=f"char:{name}")]]
        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(buttons))
        return

    lines = [f"🌀 Пассивки — {name}", f"Надето: {len(equipped)}/{economy.MAX_EQUIPPED_PASSIVES_PER_CHARACTER}\n"]
    buttons = []
    for pid in owned:
        is_on = pid in equipped
        label = ("✅ " if is_on else "⬜ ") + passives_module.PASSIVE_NAMES.get(pid, pid)
        buttons.append([InlineKeyboardButton(label, callback_data=f"togglepassive:{name}:{pid}")])
    buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data=f"char:{name}")])
    await query.edit_message_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(buttons))


async def _try_level_up(query, player, name):
    char_state = player["characters"][name]
    base_forms = _base_forms(name)
    form_index = char_state["form_index"]

    if form_index + 1 >= len(base_forms):
        await query.edit_message_text(
            "Это уже максимальная база персонажа — дальше только ветки (кнопка «Расширение»).",
            reply_markup=_character_card_keyboard(name, player),
        )
        return

    current_form = base_forms[form_index]
    quest_done = char_state["quest_line_done"].get(current_form, False)
    cost = economy.level_up_cost(name, form_index, len(base_forms))
    ok, missing = has_materials(player, cost["materials"])

    problems = []
    if not quest_done:
        problems.append(f"❌ квест-линия для «{current_form}» не пройдена")
    if not ok:
        missing_text = ", ".join(f"{m} ×{q}" for m, q in missing.items())
        problems.append(f"❌ не хватает материалов: {missing_text}")

    if problems:
        req_text = ", ".join(f"{m} ×{q}" for m, q in cost["materials"].items()) or "только квест-линия (материалов не нужно)"
        text = "Нельзя повысить уровень:\n" + "\n".join(problems) + f"\n\nТребуется: {req_text}"
        await query.edit_message_text(text, reply_markup=_character_card_keyboard(name, player))
        return

    spend_materials(player, cost["materials"])
    char_state["form_index"] += 1
    save_player(player)
    await query.edit_message_text(
        f"✅ Уровень повышен! Новая форма: «{base_forms[char_state['form_index']]}»",
        reply_markup=_character_card_keyboard(name, player),
    )


async def _start_quest_line_fight(update, context, player, name):
    """Квест-линия базового уровня = победа в личном бою ('Нападении').
    Материалы — по тому же шансу, что и в 'Личных Боссах' (это тот же
    противник, поэтому гарантированный дроп здесь был бы дырой в экономике)."""
    query = update.callback_query
    char_state = player["characters"][name]
    base_forms = _base_forms(name)
    all_forms = game_data.get_character_forms(name)
    form_index = min(char_state["form_index"], len(base_forms) - 1) if base_forms else 0
    form = base_forms[form_index] if base_forms else None

    if not form:
        await query.edit_message_text(
            "У этого персонажа нет обычных уровней с квест-линией (например, он отладочный/стартовый).",
            reply_markup=_character_card_keyboard(name, player),
        )
        return

    total_index_in_all_forms = all_forms.index(form)
    attack = game_data.get_attack_for_form_index(name, total_index_in_all_forms, len(all_forms))
    if not attack:
        await query.edit_message_text(
            "Для этого персонажа личные бои ещё не настроены.",
            reply_markup=_character_card_keyboard(name, player),
        )
        return

    enemy = battle_engine.Enemy(f"Эхо: {name} ({form})", attack["enemy_hp"], attack["enemy_dmg"])
    session = battle_engine.start_battle(
        update.effective_user.id, player, [enemy],
        on_finish_reward={"quest_line_for": (name, form), "loot_roll": (name, form_index)},
        context_label=f"⚔️ Нападение: {name}",
    )
    from handlers.battle import render_battle
    await render_battle(update, context, session, edit=True)


# ---------------------- ВЕТКИ / РАСШИРЕНИЯ ----------------------

async def _show_branch_menu(query, player, name):
    branches = _branch_forms(name)
    if not branches:
        await query.edit_message_text(
            f"У {name} пока нет веток развития.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data=f"char:{name}")]]),
        )
        return

    char_state = player["characters"][name]
    lines = [f"🌿 Ветки развития — {name}:\n"]
    buttons = []
    for i, b in enumerate(branches):
        unlocked = b in char_state.get("unlocked_branches", [])
        icon = "✅" if unlocked else "🔒"
        lines.append(f"{icon} {b}")
        buttons.append([InlineKeyboardButton(b, callback_data=f"branchinfo:{name}:{i}")])

    active_branch = char_state.get("active_branch")
    if active_branch:
        buttons.append([InlineKeyboardButton("↩️ Снять ветку (вернуться к базе)", callback_data=f"branchdeactivate:{name}")])

    buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data=f"char:{name}")])
    await query.edit_message_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(buttons))


async def _show_branch_card(query, player, name, branch):
    char_state = player["characters"][name]
    base_forms = _base_forms(name)
    branches = _branch_forms(name)
    idx = branches.index(branch)
    is_maxed = char_state["form_index"] + 1 >= len(base_forms)
    unlocked = branch in char_state.get("unlocked_branches", [])
    quest_done = char_state.get("branch_quest_done", {}).get(branch, False)

    rank = _branch_rank(branch)
    cost = economy.branch_unlock_cost(name, branch)
    ok, missing = has_materials(player, cost["materials"])

    lines = [f"🌿 {branch}", f"Ранг: {rank}", ""]
    if cost.get("extra_requirement"):
        lines.append(f"⚠️ Доп. условие (проверь сам): {cost['extra_requirement']}")
    lines.append(f"Максимальная база персонажа: {'✅' if is_maxed else '❌ (нужно сначала докачать базу)'}")
    lines.append(f"Квест линия ветки: {'✅' if quest_done else '❌'}")
    lines.append(f"Разблокировано: {'✅' if unlocked else '❌'}")
    if not unlocked:
        if cost["materials"]:
            lines.append("\nТребуется: " + ", ".join(f"{m} ×{q}" for m, q in cost["materials"].items()))
        else:
            lines.append("\nТребуется: только квест-линия (материалов не нужно)")
        for m, q in missing.items():
            lines.append(f"  ❌ не хватает {m} ×{q}")

    buttons = []
    if not quest_done:
        buttons.append([InlineKeyboardButton("📜 Квест линия ветки", callback_data=f"branchquest:{name}:{idx}")])
    if not unlocked:
        buttons.append([InlineKeyboardButton("🔓 Открыть ветку", callback_data=f"branchunlock:{name}:{idx}")])
    else:
        if char_state.get("active_branch") != branch:
            buttons.append([InlineKeyboardButton("▶️ Использовать в бою", callback_data=f"branchactivate:{name}:{idx}")])
    buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data=f"charbranch:{name}")])

    await query.edit_message_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(buttons))


async def _start_branch_quest_fight(update, context, player, name, branch):
    query = update.callback_query
    core_name = _branch_core_name(branch)

    attack = None
    for a in game_data.attacks:
        if a["character"] == name and _branch_core_name(a["form"]) == core_name:
            attack = a
            break

    branches = _branch_forms(name)
    idx = branches.index(branch)

    if not attack:
        await query.edit_message_text(
            "Для этой ветки личный бой ещё не настроен.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data=f"branchinfo:{name}:{idx}")]]),
        )
        return

    enemy = battle_engine.Enemy(f"Эхо: {name} [{branch}]", attack["enemy_hp"], attack["enemy_dmg"])
    session = battle_engine.start_battle(
        update.effective_user.id, player, [enemy],
        on_finish_reward={"branch_for": (name, branch)},
        context_label=f"⚔️ Нападение (ветка): {name}",
    )
    from handlers.battle import render_battle
    await render_battle(update, context, session, edit=True)


async def _try_unlock_branch(query, player, name, branch):
    char_state = player["characters"][name]
    base_forms = _base_forms(name)

    if char_state["form_index"] + 1 < len(base_forms):
        await query.answer("Сначала докачай базовую линию персонажа до максимума!", show_alert=True)
        return

    if not char_state.get("branch_quest_done", {}).get(branch, False):
        await query.answer("Сначала пройди квест-линию ветки!", show_alert=True)
        return

    cost = economy.branch_unlock_cost(name, branch)
    ok, missing = has_materials(player, cost["materials"])
    if not ok:
        await query.answer("Не хватает материалов на открытие ветки.", show_alert=True)
        return

    spend_materials(player, cost["materials"])
    char_state.setdefault("unlocked_branches", []).append(branch)
    save_player(player)

    await query.edit_message_text(
        f"🎉 Ветка «{branch}» открыта!",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data=f"charbranch:{name}")]]),
    )

# -*- coding: utf-8 -*-
"""
Раздел "Крафт" — см. лист "UI Прочие Меню" дизайн-документа.

ПИЛОТНОЕ УПРОЩЕНИЕ: квест-линия оружия в этой версии считается
автоматически пройденной (в общем дизайн-документе она только
отмечена как "Да" — нужна, но конкретное содержание испытания под
каждое орудие ещё не расписано отдельно от общей системы личных
рейдов). Проверка материалов — уже полностью настоящая и рабочая.
"""

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from core.player import get_player, has_materials, spend_materials, save_player
from core.game_data import game_data
from core import economy
from core import passives as passives_module


async def show_craft_categories(update: Update, context: ContextTypes.DEFAULT_TYPE):
    buttons = InlineKeyboardMarkup([
        [InlineKeyboardButton("⚔️ Оружие", callback_data="craft:cat:weapons")],
        [InlineKeyboardButton("🌀 Пассивки", callback_data="craft:cat:passives")],
        [InlineKeyboardButton("⬅️ Назад", callback_data="craft:back")],
    ])
    await update.message.reply_text("🔨 Выбери, что хочешь скрафтить:", reply_markup=buttons)


def _weapon_card_text(player, weapon):
    ok, missing = has_materials(player, weapon["requirements"])
    lines = [f"⚔️ {weapon['name']}", f"Бонус: +{int(weapon['damage_bonus_percent']*100)}% ко всем атакам", ""]
    lines.append("Требуется:")
    for mat, qty in weapon["requirements"].items():
        have = player["inventory"]["materials"].get(mat, 0)
        mark = "✅" if have >= qty else "❌"
        lines.append(f"  {mark} {mat} — {have}/{qty}")

    quest_done = player.get("weapon_quest_lines", {}).get(weapon["name"], True)  # см. пилотное упрощение
    lines.append(f"\nКвест линия: {'✅' if quest_done else '❌'}")
    lines.append(f"\n{weapon['note']}")
    return "\n".join(lines)


def _passive_card_text(player, passive_id):
    recipe = economy.PASSIVE_CRAFT_RECIPES[passive_id]
    owned = passive_id in player["inventory"].get("passives", [])
    lines = [f"{passives_module.PASSIVE_NAMES[passive_id]}", ""]
    if owned:
        lines.append("✅ Уже скрафчено — экипируется через карточку персонажа (кнопка «🌀 Пассивки»).")
        return "\n".join(lines)

    lines.append("Требуется:")
    for mat, qty in recipe["materials"].items():
        have = player["inventory"]["materials"].get(mat, 0)
        mark = "✅" if have >= qty else "❌"
        lines.append(f"  {mark} {mat} — {have}/{qty}")
    lines.append(f"  {'✅' if player['yen'] >= recipe['yen'] else '❌'} {recipe['yen']} Йен")
    return "\n".join(lines)


async def craft_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = update.effective_user
    player = get_player(user.id, user.username)
    data = query.data

    if data == "craft:back":
        await query.edit_message_text("Закрыто.")
        return

    if data == "craft:cat:weapons":
        buttons = [[InlineKeyboardButton(w["name"], callback_data=f"craft:item:{w['name']}")] for w in game_data.weapons]
        buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="craft:back")])
        await query.edit_message_text("Выбери орудие:", reply_markup=InlineKeyboardMarkup(buttons))
        return

    if data == "craft:cat:passives":
        buttons = []
        for pid, name in passives_module.PASSIVE_NAMES.items():
            owned = pid in player["inventory"].get("passives", [])
            label = f"✅ {name}" if owned else name
            buttons.append([InlineKeyboardButton(label, callback_data=f"craft:passive:{pid}")])
        buttons.append([InlineKeyboardButton("⬅️ Назад", callback_data="craft:back")])
        await query.edit_message_text("Выбери пассивную способность:", reply_markup=InlineKeyboardMarkup(buttons))
        return

    if data.startswith("craft:passive:"):
        pid = data.split("craft:passive:", 1)[1]
        owned = pid in player["inventory"].get("passives", [])
        buttons = [[InlineKeyboardButton("⬅️ Назад", callback_data="craft:cat:passives")]]
        if not owned:
            buttons.insert(0, [InlineKeyboardButton("🔨 Крафт", callback_data=f"craft:makepassive:{pid}")])
        await query.edit_message_text(_passive_card_text(player, pid), reply_markup=InlineKeyboardMarkup(buttons))
        return

    if data.startswith("craft:makepassive:"):
        pid = data.split("craft:makepassive:", 1)[1]
        recipe = economy.PASSIVE_CRAFT_RECIPES[pid]
        ok, missing = has_materials(player, recipe["materials"])
        if not ok or player["yen"] < recipe["yen"]:
            await query.answer("Не хватает материалов или Йен.", show_alert=True)
            return
        spend_materials(player, recipe["materials"])
        player["yen"] -= recipe["yen"]
        player["inventory"].setdefault("passives", []).append(pid)
        save_player(player)
        buttons = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data="craft:cat:passives")]])
        await query.edit_message_text(
            f"✅ Скрафчено: {passives_module.PASSIVE_NAMES[pid]}!\nЭкипируй её на персонажа через карточку (кнопка «🌀 Пассивки»).",
            reply_markup=buttons,
        )
        return

    if data.startswith("craft:item:"):
        name = data.split("craft:item:", 1)[1]
        weapon = game_data.get_weapon(name)
        buttons = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔨 Крафт", callback_data=f"craft:make:{name}")],
            [InlineKeyboardButton("⬅️ Назад", callback_data="craft:cat:weapons")],
        ])
        await query.edit_message_text(_weapon_card_text(player, weapon), reply_markup=buttons)
        return

    if data.startswith("craft:make:"):
        name = data.split("craft:make:", 1)[1]
        weapon = game_data.get_weapon(name)
        ok, missing = has_materials(player, weapon["requirements"])
        quest_done = player.get("weapon_quest_lines", {}).get(name, True)

        if not quest_done:
            await query.answer("Квест линия ещё не пройдена!", show_alert=True)
            return
        if not ok:
            missing_text = ", ".join(f"{m} ×{q}" for m, q in missing.items())
            await query.answer(f"Не хватает: {missing_text}", show_alert=True)
            return

        spend_materials(player, weapon["requirements"])
        owned_weapons = player["inventory"].setdefault("weapons", [])
        owned_weapons.append(name)
        save_player(player)

        buttons = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data="craft:cat:weapons")]])
        await query.edit_message_text(f"✅ Скрафчено: {name}!", reply_markup=buttons)
        return

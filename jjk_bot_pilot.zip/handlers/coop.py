# -*- coding: utf-8 -*-
"""
UI совместных рейдов. Логика раундов — в core/coop_raid.py.

Ключевая техническая деталь: у каждого из двух игроков СВОЙ чат с
ботом, поэтому при каждом действии бот обновляет статус ОБОИМ
участникам через context.bot.send_message.
"""

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from core import coop_raid
from core.player import get_player, save_player
from core.game_data import game_data


def _main_keyboard(session, user_id):
    if session.finished:
        return None
    if session.current_player_id() != user_id:
        return None
    buttons = []
    for s in session.players[user_id].available_skills():
        label = f"{s['name']} ({s['cost']} ПЭ)"
        if not s["usable"]:
            label = f"🔒 {label}"
        buttons.append([InlineKeyboardButton(label, callback_data=f"coop:skill:{s['num']}")])
    return InlineKeyboardMarkup(buttons)


async def _broadcast_status(context, session):
    for uid in session.turn_order:
        ps = session.players[uid]
        keyboard = _main_keyboard(session, uid)
        text = session.status_text()
        if session.current_player_id() != uid and not session.finished:
            text += "\n\n⏳ Ждёшь хода второго участника..."
        try:
            await context.bot.send_message(chat_id=ps.chat_id, text=text, reply_markup=keyboard)
        except Exception:
            pass  # не роняем весь рейд из-за проблем с одним сообщением


async def start_coop_raid(update, context, boss, enemy):
    """Вызывается из handlers/menu_hub.py при нажатии '👥 Совместный рейд'."""
    user = update.effective_user
    session = coop_raid.create_session(boss["name"], enemy)
    coop_raid.link_user_to_session(user.id, session.code)

    player = get_player(user.id, user.username)
    char_name = player["equipped_character"]
    char_state = player["characters"][char_name]
    forms = game_data.get_character_forms(char_name)
    form = char_state.get("active_branch") or forms[min(char_state["form_index"], len(forms) - 1)]
    skills = game_data.get_skills_for_form(char_name, form)

    session.add_player(user.id, update.effective_chat.id, player, char_name, skills)

    text = (
        f"👥 Комната создана для рейда «{boss['name']}»!\n"
        f"Код комнаты: `{session.code}`\n\n"
        f"Скинь этот код другу — пусть напишет боту:\n"
        f"/join {session.code}"
    )
    await update.callback_query.edit_message_text(text, parse_mode="Markdown")


async def join_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not context.args:
        await update.message.reply_text("Формат: /join <код комнаты>")
        return

    code = context.args[0]
    session = coop_raid.get_session_by_code(code)
    if not session:
        await update.message.reply_text("Комната с таким кодом не найдена (или рейд уже завершён).")
        return
    if session.is_full():
        await update.message.reply_text("Комната уже заполнена.")
        return

    player = get_player(user.id, user.username)
    char_name = player["equipped_character"]
    char_state = player["characters"][char_name]
    forms = game_data.get_character_forms(char_name)
    form = char_state.get("active_branch") or forms[min(char_state["form_index"], len(forms) - 1)]
    skills = game_data.get_skills_for_form(char_name, form)

    ok = session.add_player(user.id, update.effective_chat.id, player, char_name, skills)
    if not ok:
        await update.message.reply_text("Не удалось присоединиться (комната заполнена или ты уже в ней).")
        return

    coop_raid.link_user_to_session(user.id, code)
    await update.message.reply_text(f"✅ Присоединился к рейду «{session.boss_name}»! Бой начинается.")

    if session.started:
        await _broadcast_status(context, session)


async def coop_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = update.effective_user
    session = coop_raid.get_session_for_user(user.id)

    if not session:
        await query.edit_message_text("Рейд не найден или уже завершён.")
        return

    if session.current_player_id() != user.id:
        await query.answer("Сейчас не твой ход!", show_alert=True)
        return

    data = query.data
    if data.startswith("coop:skill:"):
        skill_num = int(data.split(":")[-1])
        ok, error = session.use_skill(user.id, skill_num)
        if not ok:
            await query.answer(error, show_alert=True)
            return

        if session.finished:
            await _finish_coop_raid(context, session)
            return

        await _broadcast_status(context, session)
        return


async def _finish_coop_raid(context, session):
    code = session.code
    header = "🎉 Победа!" if session.victory else "💀 Поражение..."

    for uid, ps in session.players.items():
        player = ps.player
        lines = [header]
        if session.victory:
            player["yen"] = player.get("yen", 0) + 8000
            lines.append(f"💰 +8000 Йен для {ps.char_name}")
        save_player(player)
        try:
            await context.bot.send_message(chat_id=ps.chat_id, text="\n".join(lines))
        except Exception:
            pass

    coop_raid.end_session(code)

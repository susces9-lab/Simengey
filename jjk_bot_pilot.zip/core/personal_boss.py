# -*- coding: utf-8 -*-
"""
"Личные Боссы" — доступны из Меню без каких-либо условий (не нужна
квест-линия, не нужен предыдущий уровень техники). Уровень босса
ВСЕГДА равен текущему уровню техники персонажа — то есть если у тебя
Годжо 1 уровня, ты будешь биться с "Годжо-боссом 1 уровня" сколько
угодно раз, пока не скрафтишь Годжо на 2 уровень — после этого босс
автоматически станет сильнее (2 уровня) и начнёт ронять материалы уже
под 3 уровень, и так далее.

Смысл: дать возможность фармить редкий лут на нужный левел-ап, не
проходя каждый раз "Квест линию" заново — она и так выполняется
автоматически с первого же убийства, а дальше это просто фарм-точка.
"""

import random

from core.game_data import game_data
from core import economy

# --- шансы дропа (специально низкие — см. просьбу "не факт что за 10 убийств выбьешь") ---
NEXT_LEVEL_MATERIAL_CHANCE = 0.22   # 22% за килл на КАЖДЫЙ материал следующего уровня
PARTIAL_DROP_FRACTION = 3            # за раз падает примерно 1/3 нужного количества

# Особый лут с ФИНАЛЬНОГО уровня — сырьё под крафт пассивных способностей.
FINAL_LEVEL_PASSIVE_DROPS = {
    "Годжо": {"Осколок Шести Глаз": 0.04, "Частица Бесконечности": 0.03},
    "Сукуна": {"Клеймо Каэнрен": 0.04},
    "Кашимо": {"Сердечник МБА": 0.04},
}


def base_forms(character):
    forms = game_data.get_character_forms(character)
    return [f for f in forms if not (f.startswith("Ветка:") or f.startswith("Авекинг:"))]


def get_personal_boss(character, form_index):
    """
    Возвращает (form_label, attack_data) для боя с личным боссом текущего
    уровня персонажа. attack_data содержит enemy_hp/enemy_dmg.
    """
    all_forms = game_data.get_character_forms(character)
    bf = base_forms(character)
    if not bf:
        return None, None
    form_index = max(0, min(form_index, len(bf) - 1))
    form = bf[form_index]
    idx_all = all_forms.index(form)
    attack = game_data.get_attack_for_form_index(character, idx_all, len(all_forms))
    return form, attack


def roll_loot(character, form_index):
    """
    Разыгрывает лут за победу над личным боссом. Возвращает dict
    {материал: количество} — может быть и пустым (это нормально и
    ожидаемо часто, шансы намеренно низкие).
    """
    bf = base_forms(character)
    loot = {}

    is_final = (form_index + 1) >= len(bf)

    if not is_final:
        cost = economy.level_up_cost(character, form_index, len(bf))
        for mat, qty in cost["materials"].items():
            if random.random() < NEXT_LEVEL_MATERIAL_CHANCE:
                amount = max(1, qty // PARTIAL_DROP_FRACTION)
                loot[mat] = loot.get(mat, 0) + amount
    else:
        for mat, chance in FINAL_LEVEL_PASSIVE_DROPS.get(character, {}).items():
            if random.random() < chance:
                loot[mat] = loot.get(mat, 0) + 1

    return loot

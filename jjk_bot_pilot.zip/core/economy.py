# -*- coding: utf-8 -*-
"""
Стоимость повышения уровня персонажа и открытия веток — берётся из
РЕАЛЬНЫХ данных общего дизайн-документа (data/level_requirements.json,
data/branch_requirements.json), а не из обезличенной формулы.

Важно: многие уровни в оригинальном дизайне НАМЕРЕННО требуют только
пройденную квест-линию, без единого материала — это не пилотное
упрощение, так и задумано автором. Материалы есть только там, где они
реально прописаны в документе.

Йены за левел-ап/открытие ветки не берутся — в оригинальном дизайне
Йены нужны только для гачи и как награда за дубликаты, левел-ап
персонажей всегда был про материалы + квест-линию.
"""

import json

with open("data/level_requirements.json", encoding="utf-8") as f:
    LEVEL_REQUIREMENTS = json.load(f)

with open("data/branch_requirements.json", encoding="utf-8") as f:
    BRANCH_REQUIREMENTS = json.load(f)


def level_up_cost(character, form_index, total_forms=None):
    """
    Возвращает {"yen": 0, "materials": {...}} — реальные материалы для
    перехода с уровня form_index на form_index+1. Если для этого уровня
    материалов не предусмотрено (только квест-линия) — materials будет
    пустым словарём, и это ПРАВИЛЬНО, а не ошибка.
    """
    reqs = LEVEL_REQUIREMENTS.get(character, [])
    materials = reqs[form_index] if form_index < len(reqs) else {}
    return {"yen": 0, "materials": dict(materials)}


def branch_unlock_cost(character, branch_label):
    """Возвращает {"yen": 0, "materials": {...}, "extra_requirement": str|None}."""
    key = f"{character}|{branch_label}"
    entry = BRANCH_REQUIREMENTS.get(key)
    if not entry:
        return {"yen": 0, "materials": {}, "extra_requirement": None}
    return {
        "yen": 0,
        "materials": dict(entry.get("materials", {})),
        "extra_requirement": entry.get("extra_requirement"),
    }


MAX_EQUIPPED_PASSIVES_PER_CHARACTER = 2

# --- Крафт пассивных способностей (сырьё — редкий дроп с финальных личных боссов) ---
ENERGY_CONCENTRATED = "Проклятая Энергия (Концентрированная)"  # для РКТ — единственной универсальной пассивки

PASSIVE_CRAFT_RECIPES = {
    "six_eyes": {"yen": 0, "materials": {"Осколок Шести Глаз": 3}},
    "infinity_b1": {"yen": 0, "materials": {"Частица Бесконечности": 3}},
    "sukuna_mark": {"yen": 0, "materials": {"Клеймо Каэнрен": 3}},
    "switch_mba": {"yen": 0, "materials": {"Сердечник МБА": 3}},
    "rkt": {"yen": 0, "materials": {ENERGY_CONCENTRATED: 20}},
}

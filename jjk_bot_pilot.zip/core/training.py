# -*- coding: utf-8 -*-
"""
Мини-игра "Тренировка" — см. лист "Статистика (Прокачка)" дизайн-документа.

Игрок выбирает ветку (Сила/Энергия/Здоровье), бот присылает случайное
число 1-9 с тематическим текстом, игрок отправляет цифру ОБЫЧНЫМ
сообщением в чат. Верно -> +1 очко + новое число. Цикл идёт, пока
не нажата инлайн-кнопка "Отмена".
"""

import random

BRANCH_PROMPTS = {
    "hp": "❤️ Держи ритм на цифре {n}!",
    "energy": "🔵 Твоя концентрация на цифре {n}",
    "damage": "💪 Ударь грушу под номером {n}!",
}

BRANCH_STAT_FIELD = {
    "hp": "points_hp",
    "energy": "points_energy",
    "damage": "points_damage",
}

# user_id -> {"branch": str, "target": int, "gained": int}
_active_training = {}


def start_training(user_id, branch):
    target = random.randint(1, 9)
    _active_training[user_id] = {"branch": branch, "target": target, "gained": 0}
    return target


def get_training(user_id):
    return _active_training.get(user_id)


def next_number(user_id):
    session = _active_training.get(user_id)
    if not session:
        return None
    session["target"] = random.randint(1, 9)
    return session["target"]


def stop_training(user_id):
    return _active_training.pop(user_id, None)


def prompt_text(branch, n):
    return BRANCH_PROMPTS[branch].format(n=n)

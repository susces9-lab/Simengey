# -*- coding: utf-8 -*-
"""
Пассивные способности — см. лист "Пассивные Способности" дизайн-документа.

НОВАЯ МОДЕЛЬ: пассивки — крафтовые предметы (см. core/economy.py
PASSIVE_CRAFT_RECIPES). Игрок крафтит их один раз в инвентарь, а потом
экипирует на ЛЮБОГО персонажа через карточку персонажа (кнопка
"🌀 Пассивки", максимум core.economy.MAX_EQUIPPED_PASSIVES_PER_CHARACTER
штук одновременно). В бою доступны только те пассивки, что экипированы
на ТЕКУЩЕГО активного персонажа — никакой жёсткой привязки "только на
Годжо" больше нет на уровне движка (хотя по лору они всё ещё сделаны
именно под этих персонажей и крафтятся из их же лута).
"""


def available_passive_ids(char_state):
    """char_state — состояние ИМЕННО ТОГО персонажа, что сейчас в бою
    (player['characters'][equipped_character])."""
    return list(char_state.get("equipped_passives", []))


PASSIVE_NAMES = {
    "six_eyes": "🔵 Шесть Глаз",
    "sukuna_mark": "🔴 Метка Сукуны",
    "switch_mba": "⚪ Свитч МБА",
    "rkt": "⚪ РКТ",
    "infinity_b1": "🔵 Бесконечность В1",
}


def infinity_b1_active(char_state):
    """Бесконечность В1 — чистый пассив без активации: работает,
    если экипирована на текущего персонажа."""
    return "infinity_b1" in char_state.get("equipped_passives", [])


def try_activate(session, passive_id):
    """
    Пытается активировать скил пассивки для текущего состояния боя.
    Возвращает (success: bool, message: str).
    Модифицирует session.passive_state напрямую.
    """
    ps = session.passive_state
    round_num = session.round_num

    if passive_id == "six_eyes_1":
        if round_num < 5:
            return False, "Скил 1 Шести Глаз доступен только с 5-го раунда."
        ps["six_eyes_active"] = True
        ps["six_eyes_rounds_left"] = 4
        ps["dmg_bonus_extra"] += 1.01
        ps["dr_extra"] += 0.60
        return True, "🔵 Max Six Eyes Output активирован! +101% урона, +60% снижение урона на 4 раунда. Открыт OverPurple."

    if passive_id == "six_eyes_2":
        if not ps.get("six_eyes_active"):
            return False, "Сначала активируй Скил 1 (Max Six Eyes Output)."
        if session.player_energy < 1000:
            return False, "Не хватает проклятой энергии (нужно 1000)."
        if ps.get("overpurple_used"):
            return False, "OverPurple уже использован в этом бою."
        session.player_energy -= 1000
        ps["overpurple_used"] = True
        best_dmg = _best_skill_damage(session)
        dmg = int(round(best_dmg * 3.0))
        if session.current_enemy:
            session.current_enemy.hp -= dmg
        return True, f"🟣 OverPurple наносит {dmg} урона (300% от лучшего скила)!"

    if passive_id == "sukuna_mark_1":
        if round_num < 3:
            return False, "Heian Mark доступен только с 3-го раунда."
        ps["sukuna_mark_active"] = True
        ps["sukuna_mark_rounds_left"] = 2
        ps["dmg_bonus_extra"] += 1.25
        ps["dr_extra"] += 0.10
        return True, "🔴 Heian Mark активирован! +125% урона, +10% снижение урона на 2 раунда. Открыт Dimension World Slash."

    if passive_id == "sukuna_mark_2":
        if not ps.get("sukuna_mark_active"):
            return False, "Сначала активируй Heian Mark."
        if session.player_energy < 650:
            return False, "Не хватает проклятой энергии (нужно 650)."
        if ps.get("dimension_slash_used"):
            return False, "Dimension World Slash уже использован в этом бою."
        session.player_energy -= 650
        ps["dimension_slash_used"] = True
        best_dmg = _best_skill_damage(session)
        dmg = int(round(best_dmg * 2.2))
        if session.current_enemy:
            session.current_enemy.hp -= dmg
        return True, f"🔴 Dimension World Slash наносит {dmg} урона (220% от лучшего скила)!"

    if passive_id == "switch_mba":
        if round_num < 6:
            return False, "Свитч МБА доступен только с 6-го раунда."
        if ps.get("mba_used"):
            return False, "МБА уже использован."
        ps["mba_used"] = True
        ps["mba_pending_death"] = True
        best_dmg = _best_skill_damage(session)
        dmg = int(round(best_dmg * 5.0))
        if session.current_enemy:
            session.current_enemy.hp -= dmg
        return True, f"⚪ Overhead Beast Amber наносит {dmg} урона (+500%)! Персонаж погибнет в конце этого раунда."

    if passive_id == "rkt_on":
        if round_num < 2:
            return False, "РКТ доступен только со 2-го раунда."
        if session.player_energy < 150:
            return False, "Не хватает проклятой энергии (нужно 150 за раунд)."
        ps["rkt_active"] = True
        return True, "⚪ RKT включён: +100 HP за раунд, −150 ПЭ за раунд, пока не выключишь или не кончится ПЭ."

    if passive_id == "rkt_off":
        ps["rkt_active"] = False
        return True, "RKT выключен вручную."

    return False, "Неизвестная способность."


def _best_skill_damage(session):
    best = 0
    for s in session.skills:
        d = s.get("damage")
        if isinstance(d, (int, float)):
            from core import formulas
            computed = formulas.compute_skill_damage(d, session.player) or 0
            best = max(best, computed)
    return best


def end_of_round_effects(session):
    """Вызывается в конце раунда — тикает длительности и применяет RKT/смерть от MBA."""
    ps = session.passive_state

    if ps.get("six_eyes_active"):
        ps["six_eyes_rounds_left"] -= 1
        if ps["six_eyes_rounds_left"] <= 0:
            ps["six_eyes_active"] = False
            ps["dmg_bonus_extra"] -= 1.01
            ps["dr_extra"] -= 0.60

    if ps.get("sukuna_mark_active"):
        ps["sukuna_mark_rounds_left"] -= 1
        if ps["sukuna_mark_rounds_left"] <= 0:
            ps["sukuna_mark_active"] = False
            ps["dmg_bonus_extra"] -= 1.25
            ps["dr_extra"] -= 0.10

    if ps.get("rkt_active"):
        if session.player_energy >= 150:
            session.player_energy -= 150
            session.player_hp = min(session.player_max_hp, session.player_hp + 100)
        else:
            ps["rkt_active"] = False  # авто-выключение при нехватке ПЭ

    if ps.get("mba_pending_death"):
        session.player_hp = 0
        ps["mba_pending_death"] = False

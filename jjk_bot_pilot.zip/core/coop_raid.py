# -*- coding: utf-8 -*-
"""
Совместные рейды — механика для топовых боссов, где нужно позвать
друга. Работает через короткий код комнаты:

1. Игрок А на карточке босса жмёт "👥 Совместный рейд" — бот создаёт
   комнату и даёт код (5 цифр).
2. Игрок А кидает этот код другу.
3. Игрок Б пишет боту "/join <код>".
4. Как только собрались двое — бой начинается. Раунды ходят по очереди:
   сначала бьёт игрок А, потом игрок Б, затем босс бьёт СЛУЧАЙНОГО
   живого участника пати (не обоих сразу) — так вдвоём проходить
   контент ощутимо быстрее и безопаснее, чем соло.
5. Победа/лут достаются ОБОИМ участникам.

Хранится в памяти процесса (не в JSON) — рейд эфемерный, как и обычный
бой; если бот перезапустится посреди рейда, комната потеряется.
"""

import random
import string

from core import formulas

_active_sessions = {}       # code -> CoopRaidSession
_user_to_code = {}          # user_id -> code (чтобы найти сессию по игроку)


def _generate_code():
    while True:
        code = "".join(random.choices(string.digits, k=5))
        if code not in _active_sessions:
            return code


class CoopPlayerState:
    def __init__(self, user_id, chat_id, player, char_name, skills):
        self.user_id = user_id
        self.chat_id = chat_id
        self.player = player
        self.char_name = char_name
        self.skills = skills
        self.max_hp = formulas.total_hp(player)
        self.hp = self.max_hp
        self.max_energy = formulas.total_energy(player)
        self.energy = self.max_energy
        self.cooldowns = {s["num"]: 0 for s in skills}

    def is_alive(self):
        return self.hp > 0

    def available_skills(self):
        result = []
        for s in self.skills:
            cd_left = self.cooldowns.get(s["num"], 0)
            cost = s["cost"] if isinstance(s["cost"], (int, float)) else 0
            usable = (cd_left == 0) and (self.energy >= cost)
            result.append({**s, "cd_left": cd_left, "usable": usable})
        return result


class CoopRaidSession:
    def __init__(self, code, boss_name, enemy):
        self.code = code
        self.boss_name = boss_name
        self.enemy = enemy
        self.players = {}          # user_id -> CoopPlayerState
        self.turn_order = []
        self.current_turn_idx = 0
        self.round_num = 1
        self.started = False
        self.finished = False
        self.victory = False
        self.last_log = []

    def add_player(self, user_id, chat_id, player, char_name, skills):
        if len(self.players) >= 2 or user_id in self.players:
            return False
        self.players[user_id] = CoopPlayerState(user_id, chat_id, player, char_name, skills)
        self.turn_order.append(user_id)
        if len(self.players) == 2:
            self.started = True
        return True

    def is_full(self):
        return len(self.players) >= 2

    def current_player_id(self):
        return self.turn_order[self.current_turn_idx]

    def other_player_id(self, user_id):
        for uid in self.turn_order:
            if uid != user_id:
                return uid
        return None

    def use_skill(self, user_id, skill_num):
        ps = self.players[user_id]
        skill = next((s for s in ps.skills if s["num"] == skill_num), None)
        if not skill:
            return False, "Скил не найден."

        cd_left = ps.cooldowns.get(skill_num, 0)
        cost = skill["cost"] if isinstance(skill["cost"], (int, float)) else 0
        if cd_left > 0:
            return False, f"«{skill['name']}» на перезарядке ({cd_left})."
        if ps.energy < cost:
            return False, f"Не хватает ПЭ (нужно {cost})."

        ps.energy -= cost
        dmg = formulas.compute_skill_damage(skill["damage"], ps.player, enemy=self.enemy)
        if dmg is not None:
            self.enemy.hp -= dmg
            self.last_log.append(f"⚔️ {ps.char_name}: {skill['name']} наносит {dmg} урона!")
        else:
            self.last_log.append(f"✨ {ps.char_name} использует {skill['name']}.")

        kd = skill["cooldown"]
        ps.cooldowns[skill_num] = kd if isinstance(kd, int) else 999

        self._advance_turn()
        return True, None

    def _advance_turn(self):
        self.current_turn_idx += 1
        if self.current_turn_idx >= len(self.turn_order):
            self.current_turn_idx = 0
            self._end_round()

    def _end_round(self):
        if self.enemy.hp <= 0:
            self.finished = True
            self.victory = True
            return

        alive = [uid for uid, ps in self.players.items() if ps.is_alive()]
        if alive:
            target_id = random.choice(alive)
            ps = self.players[target_id]
            ps.hp -= self.enemy.dmg
            self.last_log.append(f"💥 Босс бьёт {ps.char_name} на {self.enemy.dmg} урона!")

        for ps in self.players.values():
            ps.energy = formulas.energy_regen(ps.energy, ps.max_energy)
            for k in list(ps.cooldowns.keys()):
                if ps.cooldowns[k] > 0:
                    ps.cooldowns[k] -= 1

        if all(not ps.is_alive() for ps in self.players.values()):
            self.finished = True
            self.victory = False
            return

        self.round_num += 1

    def status_text(self):
        lines = [f"👥 Совместный рейд: {self.boss_name}", f"Раунд {self.round_num}", ""]
        lines.append(f"👹 ХП босса: {max(self.enemy.hp,0)}/{self.enemy.max_hp}")
        lines.append("")
        for uid in self.turn_order:
            ps = self.players[uid]
            marker = "➡️ " if uid == self.current_player_id() and not self.finished else "   "
            lines.append(f"{marker}{ps.char_name}: {max(ps.hp,0)}/{ps.max_hp} HP | {ps.energy}/{ps.max_energy} ПЭ")
        if self.last_log:
            lines.append("")
            lines.extend(self.last_log[-4:])
        return "\n".join(lines)


def create_session(boss_name, enemy):
    code = _generate_code()
    session = CoopRaidSession(code, boss_name, enemy)
    _active_sessions[code] = session
    return session


def get_session_by_code(code):
    return _active_sessions.get(code)


def get_session_for_user(user_id):
    code = _user_to_code.get(user_id)
    return _active_sessions.get(code) if code else None


def link_user_to_session(user_id, code):
    _user_to_code[user_id] = code


def end_session(code):
    session = _active_sessions.pop(code, None)
    if session:
        for uid in session.turn_order:
            _user_to_code.pop(uid, None)

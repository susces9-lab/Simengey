# -*- coding: utf-8 -*-
"""
Хранилище данных игроков.

КЛЮЧЕВОЙ МОМЕНТ ПО ЗАДАНИЮ: при первом обращении к боту (/start или
любое действие) для нового Telegram-пользователя автоматически
создаётся JSON-файл players/<user_id>.json со стартовым состоянием.
Ничего вручную создавать не нужно — папка players/ и файлы появляются
сами при первом запуске бота и первом сообщении от каждого игрока.
"""

import json
import os

from config import PLAYERS_DIR, START_YEN, START_LEVEL

STARTER_CHARACTER = "Парень (стартовый)"

# Юзернеймы (без @, регистр не важен), которым при первом входе
# автоматически выдаётся отладочный персонаж Divine Art —
# нужен разработчику, чтобы быстро тестировать механики без прокачки.
DEBUG_CHARACTER_NAME = "Divine Art"
DEBUG_WHITELIST_USERNAMES = {"fallengluton"}


def _player_path(user_id):
    return os.path.join(PLAYERS_DIR, f"{user_id}.json")


def _default_player(user_id, username):
    characters = {
        STARTER_CHARACTER: {
            "form_index": 0,      # индекс текущей формы/уровня в списке форм
            "quest_line_done": {},  # {form: True/False}
            "accessory": None,
        }
    }

    if username and username.lower() in DEBUG_WHITELIST_USERNAMES:
        characters[DEBUG_CHARACTER_NAME] = {
            "form_index": 0,
            "quest_line_done": {},
            "accessory": None,
        }

    return {
        "user_id": user_id,
        "username": username,
        "yen": START_YEN,
        "level": START_LEVEL,
        "stat_points_free": 0,       # свободные очки прокачки (с уровней)
        "points_hp": 0,
        "points_energy": 0,
        "points_damage": 0,
        "equipped_character": STARTER_CHARACTER,
        "characters": characters,
        "inventory": {
            "materials": {},   # {"название материала": количество}
        },
        "quests_completed": [],   # id пройденных квестов (для статистики, не блокирует повтор)
    }


def ensure_storage_dir():
    """Создаёт папку players/, если её ещё нет (первый запуск бота)."""
    os.makedirs(PLAYERS_DIR, exist_ok=True)


def get_player(user_id, username=None):
    """
    Возвращает данные игрока. Если игрок обращается впервые —
    создаёт для него новый JSON-файл со стартовым состоянием
    (в т.ч. выдаёт стартового персонажа "Парень").
    """
    ensure_storage_dir()
    path = _player_path(user_id)
    if not os.path.exists(path):
        player = _default_player(user_id, username)
        save_player(player)
        return player

    with open(path, "r", encoding="utf-8") as f:
        player = json.load(f)

    # Ретроактивная выдача отладочного перса, если игрок уже существовал
    # до того, как эта функция была добавлена в код.
    if (
        username
        and username.lower() in DEBUG_WHITELIST_USERNAMES
        and DEBUG_CHARACTER_NAME not in player["characters"]
    ):
        player["characters"][DEBUG_CHARACTER_NAME] = {
            "form_index": 0,
            "quest_line_done": {},
            "accessory": None,
        }
        save_player(player)

    return player


def save_player(player):
    ensure_storage_dir()
    path = _player_path(player["user_id"])
    with open(path, "w", encoding="utf-8") as f:
        json.dump(player, f, ensure_ascii=False, indent=2)


def add_yen(player, amount):
    player["yen"] += amount
    save_player(player)


def spend_yen(player, amount):
    if player["yen"] < amount:
        return False
    player["yen"] -= amount
    save_player(player)
    return True


def add_material(player, name, qty=1):
    inv = player["inventory"]["materials"]
    inv[name] = inv.get(name, 0) + qty
    save_player(player)


def has_materials(player, requirements: dict):
    """requirements: {"название материала": нужное_количество}"""
    inv = player["inventory"]["materials"]
    missing = {}
    for mat, need in requirements.items():
        have = inv.get(mat, 0)
        if have < need:
            missing[mat] = need - have
    return (len(missing) == 0, missing)


def spend_materials(player, requirements: dict):
    ok, missing = has_materials(player, requirements)
    if not ok:
        return False
    inv = player["inventory"]["materials"]
    for mat, need in requirements.items():
        inv[mat] -= need
        if inv[mat] <= 0:
            del inv[mat]
    save_player(player)
    return True


def add_character(player, name):
    if name not in player["characters"]:
        player["characters"][name] = {
            "form_index": 0,
            "quest_line_done": {},
            "accessory": None,
        }
        save_player(player)
        return True  # новый персонаж
    return False  # уже был — дубликат

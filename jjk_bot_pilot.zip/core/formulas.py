# -*- coding: utf-8 -*-
"""
Формулы для расчёта итоговых характеристик персонажа.
См. лист "Статистика (Прокачка)" дизайн-документа.
"""

from config import (
    BASE_HP, BASE_ENERGY, HP_PER_POINT, ENERGY_PER_POINT,
    DAMAGE_PERCENT_PER_POINT,
)


def _parse_percent(value):
    """Аксессуары хранят бафы как строку '+10%' или '—' (нет бафа)."""
    if not value or value == "—":
        return 0.0
    return float(str(value).replace("%", "").replace("+", "")) / 100.0


def total_hp(player):
    hp = BASE_HP + player["points_hp"] * HP_PER_POINT
    acc = get_equipped_accessory_buffs(player)
    hp *= (1 + acc["hp"])
    return int(round(hp))


def total_energy(player):
    energy = BASE_ENERGY + player["points_energy"] * ENERGY_PER_POINT
    acc = get_equipped_accessory_buffs(player)
    energy *= (1 + acc["energy"])
    return int(round(energy))


def damage_multiplier(player):
    mult = 1 + player["points_damage"] * DAMAGE_PERCENT_PER_POINT
    acc = get_equipped_accessory_buffs(player)
    mult *= (1 + acc["damage"])
    return mult


def get_equipped_accessory_buffs(player):
    """Смотрит аксессуар ТЕКУЩЕГО экипированного персонажа."""
    from core.game_data import game_data

    char_name = player.get("equipped_character")
    char_state = player["characters"].get(char_name, {})
    acc_name = char_state.get("accessory")
    if not acc_name:
        return {"hp": 0.0, "damage": 0.0, "energy": 0.0}

    acc = game_data.get_accessory(acc_name)
    if not acc:
        return {"hp": 0.0, "damage": 0.0, "energy": 0.0}

    return {
        "hp": _parse_percent(acc.get("hp_buff")),
        "damage": _parse_percent(acc.get("dmg_buff")),
        "energy": _parse_percent(acc.get("pe_buff")),
    }


def compute_skill_damage(base_damage, player, enemy=None):
    """Итоговый урон скила = базовый урон техники * множитель от очков Силы/акса.

    Спец-случай: если damage — строка вида "25%_of_enemy_max_hp" (используется
    отладочным персонажем Divine Art), урон считается как процент от
    МАКСИМАЛЬНОГО ХП текущего врага и НЕ умножается на стат-бонусы —
    это чит-инструмент для быстрой проверки механик, а не боевая техника.
    """
    if isinstance(base_damage, str) and base_damage.endswith("_of_enemy_max_hp"):
        if enemy is None:
            return 0
        percent = float(base_damage.split("%")[0]) / 100.0
        return int(round(enemy.max_hp * percent))

    if not isinstance(base_damage, (int, float)):
        return None  # скил без прямого урона (баф/эффект/дебафф)
    return int(round(base_damage * damage_multiplier(player)))


def energy_regen(current_energy, max_energy):
    """+20% от МАКСИМУМА за раунд, но не выше максимума."""
    from config import ENERGY_REGEN_PERCENT

    gain = int(round(max_energy * ENERGY_REGEN_PERCENT))
    return min(max_energy, current_energy + gain)

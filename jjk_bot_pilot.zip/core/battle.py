# -*- coding: utf-8 -*-
"""
Движок боя. См. лист "Механика Боя" дизайн-документа:

- Игрок всегда ходит первым.
- 3 кнопки: Сбежать / ПТ (проклятая техника) / ПС (пассивная способность).
- У любого персонажа скил №1 всегда имеет КД 0 — бить есть чем всегда.
- ПЭ восстанавливается на +20% от МАКСИМУМА каждый раунд, не выше максимума.
- Враг каждый раунд наносит ОДИНАКОВЫЙ фиксированный урон (упрощённый ИИ).
- Бой идёт до тех пор, пока чьё-то ХП не станет <= 0.

Активные бои хранятся в памяти процесса (bat_sessions), поскольку это
кратковременное состояние одного конкретного боя, а не долгосрочные
данные игрока (те лежат в JSON через core/player.py).
"""

from core.game_data import game_data
from core import formulas
from core import passives as passives_module

# user_id -> BattleSession
_active_battles = {}


class Enemy:
    def __init__(self, name, hp, dmg):
        self.name = name
        self.max_hp = hp
        self.hp = hp
        self.dmg = dmg

    def is_dead(self):
        return self.hp <= 0


class BattleSession:
    def __init__(self, player, enemies, on_finish_reward=None, context_label=""):
        """
        enemies: список Enemy — сражаются по очереди (для квестов, где нужно
                 убить нескольких врагов подряд).
        on_finish_reward: dict с описанием награды за победу (может быть None).
        """
        self.player = player
        self.enemies = enemies
        self.enemy_index = 0
        self.on_finish_reward = on_finish_reward or {}
        self.context_label = context_label

        char_name = player["equipped_character"]
        char_state = player["characters"][char_name]
        self.char_state = char_state  # нужно пассивкам, чтобы знать что экипировано
        forms = game_data.get_character_forms(char_name)
        active_branch = char_state.get("active_branch")
        if active_branch and active_branch in forms:
            form = active_branch
        else:
            form = forms[min(char_state["form_index"], len(forms) - 1)] if forms else None
        self.form = form
        self.skills = game_data.get_skills_for_form(char_name, form) if form else []

        self.player_max_hp = formulas.total_hp(player)
        self.player_hp = self.player_max_hp
        self.player_max_energy = formulas.total_energy(player)
        self.player_energy = self.player_max_energy

        # состояние пассивных способностей (см. core/passives.py)
        self.passive_state = {
            "dmg_bonus_extra": 0.0,
            "dr_extra": 0.0,
            "six_eyes_active": False, "six_eyes_rounds_left": 0, "overpurple_used": False,
            "sukuna_mark_active": False, "sukuna_mark_rounds_left": 0, "dimension_slash_used": False,
            "switch_mba_used": False, "mba_used": False, "mba_pending_death": False,
            "rkt_active": False,
        }

        # КД каждого скила: {skill_num: раундов_осталось}
        self.cooldowns = {s["num"]: 0 for s in self.skills}
        self.round_num = 1
        self.finished = False
        self.victory = False
        self.last_log = []

    @property
    def current_enemy(self):
        if self.enemy_index >= len(self.enemies):
            return None
        return self.enemies[self.enemy_index]

    def available_skills(self):
        result = []
        for s in self.skills:
            cd_left = self.cooldowns.get(s["num"], 0)
            cost = s["cost"] if isinstance(s["cost"], (int, float)) else 0
            usable = (cd_left == 0) and (self.player_energy >= cost)
            result.append({**s, "cd_left": cd_left, "usable": usable})
        return result

    def use_skill(self, skill_num):
        self.last_log = []
        skill = next((s for s in self.skills if s["num"] == skill_num), None)
        if not skill:
            return False, "Скил не найден."

        cd_left = self.cooldowns.get(skill_num, 0)
        cost = skill["cost"] if isinstance(skill["cost"], (int, float)) else 0
        if cd_left > 0:
            return False, f"«{skill['name']}» ещё на перезарядке ({cd_left} раунд(ов))."
        if self.player_energy < cost:
            return False, f"Не хватает проклятой энергии для «{skill['name']}» (нужно {cost})."

        # тратим ПЭ
        self.player_energy -= cost

        # урон
        dmg = formulas.compute_skill_damage(skill["damage"], self.player, enemy=self.current_enemy)
        if dmg is not None and self.passive_state["dmg_bonus_extra"]:
            dmg = int(round(dmg * (1 + self.passive_state["dmg_bonus_extra"])))
        enemy = self.current_enemy
        if dmg is not None and enemy:
            enemy.hp -= dmg
            self.last_log.append(f"⚔️ {skill['name']} наносит {dmg} урона по {enemy.name}!")
        else:
            self.last_log.append(f"✨ {skill['name']} использован (эффект без прямого урона).")

        # ставим кд (только если это число; спец-обозначения * и • обрабатываем как "долгий кд")
        kd = skill["cooldown"]
        if isinstance(kd, int):
            self.cooldowns[skill_num] = kd
        else:
            self.cooldowns[skill_num] = 999  # спец-скилы (домены и т.п.) — пилотная заглушка: 1 раз за бой

        return True, None

    def enemy_turn(self):
        enemy = self.current_enemy
        if not enemy or enemy.is_dead():
            return
        dmg = enemy.dmg
        dr = self.passive_state["dr_extra"]
        if passives_module.infinity_b1_active(self.char_state):
            dr += 0.20  # Бесконечность В1 — постоянный пассив на Годжо
        dmg = int(round(dmg * (1 - min(dr, 0.95))))
        self.player_hp -= dmg
        self.last_log.append(f"💥 {enemy.name} бьёт в ответ на {dmg} урона!" + (f" (снижено пассивками с {enemy.dmg})" if dr else ""))

    def end_round(self):
        # проверка смерти врага -> следующий враг
        enemy = self.current_enemy
        if enemy and enemy.is_dead():
            self.last_log.append(f"☠️ {enemy.name} повержен!")
            self.enemy_index += 1
            if self.enemy_index >= len(self.enemies):
                self.finished = True
                self.victory = True
                return

        if self.player_hp <= 0:
            self.finished = True
            self.victory = False
            return

        # регенерация ПЭ и снижение КД
        self.player_energy = formulas.energy_regen(self.player_energy, self.player_max_energy)
        for k in list(self.cooldowns.keys()):
            if self.cooldowns[k] > 0:
                self.cooldowns[k] -= 1

        # тик пассивок (RKT/длительности бафов/отложенная смерть от MBA)
        passives_module.end_of_round_effects(self)
        if self.player_hp <= 0:
            self.finished = True
            self.victory = False
            return

        self.round_num += 1

    def status_text(self):
        enemy = self.current_enemy
        lines = []
        if self.context_label:
            lines.append(f"📍 {self.context_label}")
        lines.append(f"Раунд {self.round_num}")
        lines.append("")
        if enemy:
            bar_e = _hp_bar(enemy.hp, enemy.max_hp)
            lines.append(f"👹 {enemy.name}\n{bar_e} {max(enemy.hp,0)}/{enemy.max_hp}")
        lines.append("")
        bar_p = _hp_bar(self.player_hp, self.player_max_hp)
        lines.append(f"🧑 {self.player['equipped_character']}\n{bar_p} {max(self.player_hp,0)}/{self.player_max_hp}")
        lines.append(f"🔵 ПЭ: {self.player_energy}/{self.player_max_energy}")
        if self.last_log:
            lines.append("")
            lines.extend(self.last_log)
        return "\n".join(lines)


def _hp_bar(cur, mx, length=10):
    cur = max(cur, 0)
    filled = int(round(length * cur / mx)) if mx else 0
    return "🟥" * filled + "⬛" * (length - filled)


def start_battle(user_id, player, enemies, on_finish_reward=None, context_label=""):
    session = BattleSession(player, enemies, on_finish_reward, context_label)
    _active_battles[user_id] = session
    return session


def get_battle(user_id):
    return _active_battles.get(user_id)


def end_battle(user_id):
    _active_battles.pop(user_id, None)

# -*- coding: utf-8 -*-
"""
Загрузка статичных игровых данных (персонажи, скилы, квесты, боссы,
гача, аксессуары) из JSON-файлов в папке data/.

Эти файлы поставляются ВМЕСТЕ с ботом (не создаются автоматически) —
их содержимое выгружено из общего дизайн-документа
(JJK_Bot_Персонажи_Материалы_Оружие.xlsx).
"""

import json
import os

from config import DATA_DIR


def _load(filename):
    path = os.path.join(DATA_DIR, filename)
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


class GameData:
    """Singleton-обёртка над всеми статичными игровыми данными."""

    def __init__(self):
        self.characters = _load("characters.json")          # список персонажей (редкость/ранг/кол-во уровней)
        self.skills = _load("skills.json")                   # {character: {form: [skills]}}
        self.quests = _load("quests.json")                   # список квестов 1-18
        self.bosses = _load("bosses.json")                   # список боссов
        gacha = _load("gacha.json")
        self.gacha_rarities = gacha["rarities"]
        self.duplicate_yen = gacha["duplicate_yen"]
        self.accessories = _load("accessories.json")
        self.attacks = _load("attacks.json")          # личные рейды ("Нападения")
        self.weapons = _load("weapons.json")            # крафтовые орудия

        self._characters_by_name = {c["name"]: c for c in self.characters}

    def get_character(self, name):
        return self._characters_by_name.get(name)

    def get_character_forms(self, name):
        """Возвращает список форм (уровней) персонажа в порядке их получения."""
        return list(self.skills.get(name, {}).keys())

    def get_skills_for_form(self, name, form):
        return self.skills.get(name, {}).get(form, [])

    def get_quest(self, quest_id):
        for q in self.quests:
            if q["id"] == quest_id:
                return q
        return None

    def available_quests(self, player_level):
        """Квесты видны только если уровень игрока >= нижней границы диапазона квеста."""
        result = []
        for q in self.quests:
            lo = int(str(q["range"]).split("-")[0])
            if player_level >= lo:
                result.append(q)
        return result

    def get_boss(self, name):
        for b in self.bosses:
            if b["name"] == name:
                return b
        return None

    def get_accessory(self, name):
        for a in self.accessories:
            if a["name"] == name:
                return a
        return None

    def get_attack(self, character, form):
        """Данные противника для личного 'Нападения' (квест-линия персонажа)."""
        for a in self.attacks:
            if a["character"] == character and a["form"] == form:
                return a
        return None

    def get_attack_for_form_index(self, character, form_index, total_forms):
        """
        Надёжный поиск личного боя по ПОЗИЦИИ формы, а не по точному названию.

        Названия уровней в skills.json ("Ур.1 — ...") и в attacks.json
        (из листа "Личные Рейды", там другие подписи) не совпадают дословно
        и иногда их разное количество на персонажа (например, в "Личных
        Рейдах" у Сукуны 5 стадий, а в skills.json — 4). Поэтому матчим
        по индексу текущей формы, пропорционально растянутому на список
        боёв ИМЕННО ЭТОГО персонажа.
        """
        entries = [a for a in self.attacks if a["character"] == character]
        if not entries:
            return None
        if total_forms <= 1:
            idx = 0
        else:
            idx = round(form_index * (len(entries) - 1) / (total_forms - 1))
        idx = max(0, min(idx, len(entries) - 1))
        return entries[idx]

    def get_weapon(self, name):
        for w in self.weapons:
            if w["name"] == name:
                return w
        return None


# Глобальный объект с данными — загружается один раз при старте бота
game_data = GameData()

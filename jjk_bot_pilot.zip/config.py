# -*- coding: utf-8 -*-
"""
Конфигурация бота.

ВАЖНО: сюда нужно вставить токен твоего Telegram-бота,
полученный от @BotFather в Telegram.
"""

import os

# Вариант 1 (проще для пилота): вписать токен прямо сюда
BOT_TOKEN = os.getenv("BOT_TOKEN", "8682966616:AAH8z-VJify_SDX4ssiGwJTU_LnDKxnY4A4")

# Пути к данным
DATA_DIR = "data"
PLAYERS_DIR = "players"

# Стартовые параметры нового игрока
START_YEN = 2000
START_LEVEL = 1
MAX_LEVEL = 3000

# Стоимость крутки гачи
GACHA_COST_1X = 1000
GACHA_COST_10X = 9000

# Формулы статов (см. дизайн-документ, лист "Статистика (Прокачка)")
BASE_HP = 100
BASE_ENERGY = 100
BASE_DAMAGE_MULT = 1.0

HP_PER_POINT = 10          # +10 HP за очко
ENERGY_PER_POINT = 10      # +10 энергии за очко
DAMAGE_PERCENT_PER_POINT = 0.005  # +0.5% урона за очко (баф от 0.1%)

POINTS_PER_LEVEL = 3        # очков прокачки за уровень
ENERGY_REGEN_PERCENT = 0.20  # +20% от МАКС. энергии за раунд

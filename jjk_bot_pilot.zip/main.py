# -*- coding: utf-8 -*-
"""
Точка входа бота.

Запуск:
    python main.py

При первом сообщении от каждого нового игрока в папке players/
автоматически создаётся файл <user_id>.json с его стартовым
состоянием (см. core/player.py) — вручную ничего создавать не нужно,
папка тоже появится сама.
"""

import logging

from telegram import Update
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters,
)

from config import BOT_TOKEN
from core.player import ensure_storage_dir

from handlers.start import start, unknown_text, MAIN_MENU_BUTTONS
from handlers.characters import show_character_list, character_callback
from handlers.gacha import show_gacha_menu, gacha_callback
from handlers.inventory import show_inventory, inventory_callback
from handlers.stats import show_stats, stats_callback, training_text_handler
from handlers.quests import show_quest_list, quest_callback
from handlers.craft import show_craft_categories, craft_callback
from handlers.menu_hub import show_menu_hub, menu_hub_callback, raids_command, bosses_command
from handlers.battle import battle_callback
from handlers.admin import give_command
from handlers.coop import join_command, coop_callback

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)


async def route_text(update: Update, context):
    """Роутер обычных текстовых сообщений: сначала проверяем, не цифра ли
    это для активной тренировки, потом смотрим на кнопки reply-меню."""
    text = update.message.text

    # 1) активная тренировка ждёт цифру?
    handled = await training_text_handler(update, context)
    if handled:
        return

    # 2) кнопки главного меню
    if text == "🧑 Персонажи":
        await show_character_list(update, context)
    elif text == "🔨 Крафт":
        await show_craft_categories(update, context)
    elif text == "🎰 Гача":
        await show_gacha_menu(update, context)
    elif text == "🎒 Инвентарь":
        await show_inventory(update, context)
    elif text == "📊 Статистика":
        await show_stats(update, context)
    elif text == "📜 Квесты":
        await show_quest_list(update, context)
    elif text == "🗂️ Меню":
        await show_menu_hub(update, context)
    else:
        await unknown_text(update, context)


def main():
    ensure_storage_dir()  # players/ создастся сама при первом запуске

    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("give", give_command))
    app.add_handler(CommandHandler("raids", raids_command))
    app.add_handler(CommandHandler("bosses", bosses_command))
    app.add_handler(CommandHandler("join", join_command))

    # Текстовые сообщения (кнопки reply-меню + цифры тренировки)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, route_text))

    # Инлайн-кнопки — по префиксу callback_data
    app.add_handler(CallbackQueryHandler(character_callback, pattern=r"^(char:|charback|charquest:|charlvlup:|charbranch:|characc:|equipacc:|charequip:|branchinfo:|branchquest:|branchunlock:|branchactivate:|branchdeactivate:|charpassives:|togglepassive:)"))
    app.add_handler(CallbackQueryHandler(gacha_callback, pattern=r"^gacha:"))
    app.add_handler(CallbackQueryHandler(inventory_callback, pattern=r"^inv:"))
    app.add_handler(CallbackQueryHandler(stats_callback, pattern=r"^stats:"))
    app.add_handler(CallbackQueryHandler(quest_callback, pattern=r"^quest"))
    app.add_handler(CallbackQueryHandler(craft_callback, pattern=r"^craft:"))
    app.add_handler(CallbackQueryHandler(menu_hub_callback, pattern=r"^hub:"))
    app.add_handler(CallbackQueryHandler(battle_callback, pattern=r"^battle:"))
    app.add_handler(CallbackQueryHandler(coop_callback, pattern=r"^coop:"))

    logger.info("Бот запущен, ждём сообщений...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
